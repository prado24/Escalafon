﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Data.Entity.Migrations;

namespace Escalafon
{
    public partial class FrmInfoUsuarioAdd : Form
    {
        //FrmEvaluar.Datos info  FrmInicioUser.Datos info
        public FrmInfoUsuarioAdd(FrmPrincipal.Datos info)
        {
            InitializeComponent();
            txtId.Text = info.id2.ToString();
            
        }

        private void estiloBoton2_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "C:\\";
            openFileDialog1.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtCursos.Text = openFileDialog1.FileName;

            }
        }

        private void txtGuardar_Click(object sender, EventArgs e)
        {
            /*if (!(txtCursos.Text == "" || txtAnti.Text == "" || txtAsesorR.Text == "" || txtAsesorT.Text == "" || txtCertificaciones.Text == "" || txtDesarrolloP.Text == "" || txtDiplomado.Text == "" || txtDireccionT.Text == "" || txtGrado.Text == "" || txtICertificados.Text == "" || txtICursos.Text == "" || txtIDiplomado.Text == ""))
            {*/
                //byte[] file = null;
                //Stream mystream = openFileDialog13.OpenFile();
                //using (MemoryStream ms = new MemoryStream())
                //{
                //    mystream.CopyTo(ms);
                //    file = ms.ToArray();
                //}
                //using (Model.EscalafonEntities4 db = new Model.EscalafonEntities4())
                using (Model2.EscalafonEntities5 db = new Model2.EscalafonEntities5())
                {
                    // Capacitacion de cursos
                    if (txtCursos.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog1.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        Model2.Archivos Document1 = new Model2.Archivos();
                            Document1.fkidusu = int.Parse(txtId.Text.Trim());
                            Document1.doc = file;
                            Document1.realname = openFileDialog1.SafeFileName;
                            Document1.categoria = lblCursos.Text;
                            db.Archivos.Add(Document1);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    // Certificaciones
                    if (txtCertificaciones.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog3.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el segundo archivo
                        Model2.Archivos Document2 = new Model2.Archivos();
                            Document2.fkidusu = int.Parse(txtId.Text.Trim());
                            Document2.doc = file;
                            Document2.realname = openFileDialog3.SafeFileName;
                            Document2.categoria = "Certificaciones";
                            db.Archivos.Add(Document2);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Imparticion de cursos
                    if (txtICursos.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog5.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el tercer archivo
                        Model2.Archivos Document3 = new Model2.Archivos();
                            Document3.fkidusu = int.Parse(txtId.Text.Trim());
                            Document3.doc = file;
                            Document3.realname = openFileDialog5.SafeFileName;
                            Document3.categoria = "Imparticion de Cursos";
                            db.Archivos.Add(Document3);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }
                    // Para imparticion de cursos st
                    if (txtICursosST.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog12.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el tercer archivo
                        Model2.Archivos Document3 = new Model2.Archivos();
                            Document3.fkidusu = int.Parse(txtId.Text.Trim());
                            Document3.doc = file;
                            Document3.realname = openFileDialog12.SafeFileName;
                            Document3.categoria = "Imparticion de Cursos ST";
                            db.Archivos.Add(Document3);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    // Para Instructor de certificaciones
                    if (txtICertificados.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog7.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el cuarto archivo
                        Model2.Archivos Document4 = new Model2.Archivos();
                            Document4.fkidusu = int.Parse(txtId.Text.Trim());
                            Document4.doc = file;
                            Document4.realname = openFileDialog7.SafeFileName;
                            Document4.categoria = "Instructor Certificaciones";
                            db.Archivos.Add(Document4);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Asesor de residencias
                    if (txtAsesorR.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog9.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el cinco archivo
                        Model2.Archivos Document5 = new Model2.Archivos();
                            Document5.fkidusu = int.Parse(txtId.Text.Trim());
                            Document5.doc = file;
                            Document5.realname = openFileDialog9.SafeFileName;
                            Document5.categoria = "Asesor Residencias";
                            db.Archivos.Add(Document5);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Direccion de Tesis
                    if (txtDireccionT.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog11.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el seis archivo
                        Model2.Archivos Document6 = new Model2.Archivos();
                            Document6.fkidusu = int.Parse(txtId.Text.Trim());
                            Document6.doc = file;
                            Document6.realname = openFileDialog11.SafeFileName;
                            Document6.categoria = "Direccion Tesis";
                            db.Archivos.Add(Document6);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Grado de Estudios
                    if (txtGrado.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog2.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el siete archivo
                        Model2.Archivos Document7 = new Model2.Archivos();
                            Document7.fkidusu = int.Parse(txtId.Text.Trim());
                            Document7.doc = file;
                            Document7.realname = openFileDialog2.SafeFileName;
                            Document7.categoria = "Grado de Estudios";
                            db.Archivos.Add(Document7);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Diplomados
                    if (txtDiplomado.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog4.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el ocho archivo
                        Model2.Archivos Document8 = new Model2.Archivos();
                            Document8.fkidusu = int.Parse(txtId.Text.Trim());
                            Document8.doc = file;
                            Document8.realname = openFileDialog4.SafeFileName;
                            Document8.categoria = "Diplomados";
                            db.Archivos.Add(Document8);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Instructor de Diplomados
                    if (txtIDiplomado.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog8.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el nueve archivo
                        Model2.Archivos Document9 = new Model2.Archivos();
                            Document9.fkidusu = int.Parse(txtId.Text.Trim());
                            Document9.doc = file;
                            Document9.realname = openFileDialog8.SafeFileName;
                            Document9.categoria = "Instructor Diplomados";
                            db.Archivos.Add(Document9);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Desarrollo de Proyecto de Investigacion
                    if (txtDesarrolloP.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog6.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el diez archivo
                        Model2.Archivos Document10 = new Model2.Archivos();
                            Document10.fkidusu = int.Parse(txtId.Text.Trim());
                            Document10.doc = file;
                            Document10.realname = openFileDialog6.SafeFileName;
                            Document10.categoria = "Desarrollo P.I.";
                            db.Archivos.Add(Document10);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Asesos de Titulaciones
                    if (txtAsesorT.Text != "")
                    {
                        byte[] file = null;
                        Stream mystream = openFileDialog10.OpenFile();
                        using (MemoryStream ms = new MemoryStream())
                        {
                            mystream.CopyTo(ms);
                            file = ms.ToArray();
                        }
                        //Para el el once archivo
                        Model2.Archivos Document11 = new Model2.Archivos();
                            Document11.fkidusu = int.Parse(txtId.Text.Trim());
                            Document11.doc = file;
                            Document11.realname = openFileDialog10.SafeFileName;
                            Document11.categoria = "Asesor Titulaciones";
                            db.Archivos.Add(Document11);
                            db.SaveChanges();
                            MessageBox.Show("Se ha guardado con exito el archivo");
                    }

                    //Antiguedad
                    if (txtAnti.Text != "")
                    {
                        //Para fecha
                        Model2.Anti Document12 = new Model2.Anti();
                        Document12.Fkidusu = int.Parse(txtId.Text.Trim());
                        Document12.Años = int.Parse(txtAnti.Text);
                        db.Anti.Add(Document12);
                        db.SaveChanges();
                        MessageBox.Show("Se ha guardado con exito la fecha");
                        //Termina fecha
                    }

                }
            //}
            //else
            //{
            //    MessageBox.Show("Agrega un documento");
            //}
            
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnA2_Click(object sender, EventArgs e)
        {
            openFileDialog2.InitialDirectory = "C:\\";
            openFileDialog2.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog2.FilterIndex = 1;
            openFileDialog2.RestoreDirectory = true;
            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                txtGrado.Text = openFileDialog2.FileName;

            }
        }

        private void btnA3_Click(object sender, EventArgs e)
        {
            openFileDialog3.InitialDirectory = "C:\\";
            openFileDialog3.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog3.FilterIndex = 1;
            openFileDialog3.RestoreDirectory = true;
            if (openFileDialog3.ShowDialog() == DialogResult.OK)
            {
                txtCertificaciones.Text = openFileDialog3.FileName;

            }
        }

        private void btnA4_Click(object sender, EventArgs e)
        {
            openFileDialog4.InitialDirectory = "C:\\";
            openFileDialog4.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog4.FilterIndex = 1;
            openFileDialog4.RestoreDirectory = true;
            if (openFileDialog4.ShowDialog() == DialogResult.OK)
            {
                txtDiplomado.Text = openFileDialog4.FileName; 

            }
        }

        private void btnA5_Click(object sender, EventArgs e)
        {
            openFileDialog5.InitialDirectory = "C:\\";
            openFileDialog5.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog5.FilterIndex = 1;
            openFileDialog5.RestoreDirectory = true;
            if (openFileDialog5.ShowDialog() == DialogResult.OK)
            {
                txtICursos.Text = openFileDialog5.FileName;

            }
        }

        private void btnA6_Click(object sender, EventArgs e)
        {
            openFileDialog6.InitialDirectory = "C:\\";
            openFileDialog6.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog6.FilterIndex = 1;
            openFileDialog6.RestoreDirectory = true;
            if (openFileDialog6.ShowDialog() == DialogResult.OK)
            {
                txtDesarrolloP.Text = openFileDialog6.FileName;

            }
        }

        private void btnA7_Click(object sender, EventArgs e)
        {
            openFileDialog7.InitialDirectory = "C:\\";
            openFileDialog7.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog7.FilterIndex = 1;
            openFileDialog7.RestoreDirectory = true;
            if (openFileDialog7.ShowDialog() == DialogResult.OK)
            {
                txtICertificados.Text = openFileDialog7.FileName;

            }
        }

        private void btnA8_Click(object sender, EventArgs e)
        {
            openFileDialog8.InitialDirectory = "C:\\";
            openFileDialog8.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog8.FilterIndex = 1;
            openFileDialog8.RestoreDirectory = true;
            if (openFileDialog8.ShowDialog() == DialogResult.OK)
            {
                //txtDesarrolloP.Text = openFileDialog8.FileName;
                txtIDiplomado.Text = openFileDialog8.FileName;

            }
        }

        private void btnA9_Click(object sender, EventArgs e)
        {
            openFileDialog9.InitialDirectory = "C:\\";
            openFileDialog9.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog9.FilterIndex = 1;
            openFileDialog9.RestoreDirectory = true;
            if (openFileDialog9.ShowDialog() == DialogResult.OK)
            {
                txtAsesorR.Text = openFileDialog9.FileName;

            }
        }

        private void btnA10_Click(object sender, EventArgs e)
        {
            openFileDialog10.InitialDirectory = "C:\\";
            openFileDialog10.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog10.FilterIndex = 1;
            openFileDialog10.RestoreDirectory = true;
            if (openFileDialog10.ShowDialog() == DialogResult.OK)
            {
                txtAsesorT.Text = openFileDialog10.FileName;

            }
        }

        private void btnA11_Click(object sender, EventArgs e)
        {
            openFileDialog11.InitialDirectory = "C:\\";
            openFileDialog11.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog11.FilterIndex = 1;
            openFileDialog11.RestoreDirectory = true;
            if (openFileDialog11.ShowDialog() == DialogResult.OK)
            {
                txtDireccionT.Text = openFileDialog11.FileName;

            }
        }

        private void FrmInfoUsuarioAdd_Load(object sender, EventArgs e)
        {

        }

        private void btnA13_Click(object sender, EventArgs e)
        {
            openFileDialog12.InitialDirectory = "C:\\";
            openFileDialog12.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog12.FilterIndex = 1;
            openFileDialog12.RestoreDirectory = true;
            if (openFileDialog12.ShowDialog() == DialogResult.OK)
            {
                txtICursosST.Text = openFileDialog12.FileName;

            }
        }
    }
}
