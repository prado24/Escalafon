﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escalafon
{
    public partial class FrmCaliAdmin : Form
    {
        public FrmCaliAdmin(FrmEvaluar.Datos info2)
        {
            InitializeComponent();
            txtId.Text = info2.id.ToString();
        }

        private void FrmCaliAdmin_Load(object sender, EventArgs e)
        {
            MostrarC();
        }
        private SqlConnection Conexion;
        public void MostrarC()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            //string con1 = "Select * From RUsuarios WHERE Usuario= " + txtUsuario.Text + "";
            var Consultar3 = new SqlCommand(string.Format("Select gradoe, antiguedad, cursos, certificaciones, diplomados, imparticioncst, instructord, imparticionc, instructorcer, desarrollopi, asesorre, asesort, direcciont From Calificacion Where fkidusu = '{0}'", int.Parse(txtId.Text)), Conexion);
            var Consultar4 = new SqlCommand(string.Format("Select Comentario from Comentarios Where fkidusu = '{0}'", int.Parse(txtId.Text)), Conexion);
            Conexion.Open();
            SqlDataReader reader2 = Consultar3.ExecuteReader();

            if (reader2.Read())
            {
                //info = new Datos();
                //txtId.Text = reader2["Idusu"].ToString();
                //cali = int.Parse(reader2["gradoe"].ToString());
                txtGrado.Text = reader2["gradoe"].ToString();
                txtAnti.Text = reader2["antiguedad"].ToString();
                txtCursos.Text = reader2["cursos"].ToString();
                txtCertificaciones.Text = reader2["certificaciones"].ToString();
                txtDiplomado.Text = reader2["diplomados"].ToString();
                txtICursosST.Text = reader2["imparticioncst"].ToString();
                txtIDiplomado.Text = reader2["instructord"].ToString();
                txtICursos.Text = reader2["imparticionc"].ToString();
                txtICertificados.Text = reader2["instructorcer"].ToString();
                txtDesarrolloP.Text = reader2["desarrollopi"].ToString();
                txtAsesorR.Text = reader2["asesorre"].ToString();
                txtAsesorT.Text = reader2["asesort"].ToString();
                txtDireccionT.Text = reader2["direcciont"].ToString();
            }
            reader2.Close();
            SqlDataReader reader3 = Consultar4.ExecuteReader();
            if (reader3.Read())
            {
                txtComentario.Text = reader3["Comentario"].ToString();
            }
            Conexion.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ibtnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
