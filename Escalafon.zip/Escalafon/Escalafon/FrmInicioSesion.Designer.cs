﻿namespace Escalafon
{
    partial class FrmInicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInicioSesion));
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.estiloBoton1 = new Escalafon.EstiloBoton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.PictureBox();
            this.PanelSombra = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ibtnCerrar = new FontAwesome.Sharp.IconPictureBox();
            this.ibtnMini = new FontAwesome.Sharp.IconPictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnMini)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(520, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "LOGIN";
            // 
            // txtUsuario
            // 
            this.txtUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsuario.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.ForeColor = System.Drawing.Color.DimGray;
            this.txtUsuario.Location = new System.Drawing.Point(346, 95);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(420, 20);
            this.txtUsuario.TabIndex = 1;
            this.txtUsuario.Text = "USUARIO";
            this.txtUsuario.Enter += new System.EventHandler(this.txtUsuario_Enter);
            this.txtUsuario.Leave += new System.EventHandler(this.txtUsuario_Leave);
            // 
            // txtContraseña
            // 
            this.txtContraseña.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txtContraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseña.ForeColor = System.Drawing.Color.DimGray;
            this.txtContraseña.Location = new System.Drawing.Point(346, 189);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(420, 19);
            this.txtContraseña.TabIndex = 2;
            this.txtContraseña.Text = "CONTRASEÑA";
            this.txtContraseña.Enter += new System.EventHandler(this.txtContraseña_Enter);
            this.txtContraseña.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContraseña_KeyPress);
            this.txtContraseña.Leave += new System.EventHandler(this.txtContraseña_Leave);
            // 
            // estiloBoton1
            // 
            this.estiloBoton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.estiloBoton1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.estiloBoton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.estiloBoton1.BorderRadius = 25;
            this.estiloBoton1.BorderSize = 0;
            this.estiloBoton1.FlatAppearance.BorderSize = 0;
            this.estiloBoton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.estiloBoton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.estiloBoton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.estiloBoton1.ForeColor = System.Drawing.Color.Gainsboro;
            this.estiloBoton1.Location = new System.Drawing.Point(348, 280);
            this.estiloBoton1.Name = "estiloBoton1";
            this.estiloBoton1.Size = new System.Drawing.Size(418, 40);
            this.estiloBoton1.TabIndex = 0;
            this.estiloBoton1.Text = "Ingresar";
            this.estiloBoton1.TextColor = System.Drawing.Color.Gainsboro;
            this.estiloBoton1.UseVisualStyleBackColor = false;
            this.estiloBoton1.Click += new System.EventHandler(this.estiloBoton1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.panel1.Controls.Add(this.btnHome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 365);
            this.panel1.TabIndex = 8;
            // 
            // btnHome
            // 
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.Location = new System.Drawing.Point(45, 95);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(143, 167);
            this.btnHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnHome.TabIndex = 13;
            this.btnHome.TabStop = false;
            // 
            // PanelSombra
            // 
            this.PanelSombra.BackColor = System.Drawing.Color.DimGray;
            this.PanelSombra.Location = new System.Drawing.Point(348, 114);
            this.PanelSombra.Name = "PanelSombra";
            this.PanelSombra.Size = new System.Drawing.Size(418, 3);
            this.PanelSombra.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(348, 215);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(418, 3);
            this.panel2.TabIndex = 10;
            // 
            // ibtnCerrar
            // 
            this.ibtnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ibtnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ibtnCerrar.ForeColor = System.Drawing.Color.DimGray;
            this.ibtnCerrar.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.ibtnCerrar.IconColor = System.Drawing.Color.DimGray;
            this.ibtnCerrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCerrar.IconSize = 27;
            this.ibtnCerrar.Location = new System.Drawing.Point(830, 0);
            this.ibtnCerrar.Name = "ibtnCerrar";
            this.ibtnCerrar.Size = new System.Drawing.Size(27, 27);
            this.ibtnCerrar.TabIndex = 11;
            this.ibtnCerrar.TabStop = false;
            this.ibtnCerrar.Click += new System.EventHandler(this.ibtnCerrar_Click);
            // 
            // ibtnMini
            // 
            this.ibtnMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ibtnMini.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ibtnMini.ForeColor = System.Drawing.Color.DimGray;
            this.ibtnMini.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            this.ibtnMini.IconColor = System.Drawing.Color.DimGray;
            this.ibtnMini.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnMini.IconSize = 27;
            this.ibtnMini.Location = new System.Drawing.Point(797, 0);
            this.ibtnMini.Name = "ibtnMini";
            this.ibtnMini.Size = new System.Drawing.Size(27, 27);
            this.ibtnMini.TabIndex = 12;
            this.ibtnMini.TabStop = false;
            this.ibtnMini.Click += new System.EventHandler(this.ibtnMini_Click);
            // 
            // FrmInicioSesion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(859, 365);
            this.Controls.Add(this.ibtnMini);
            this.Controls.Add(this.ibtnCerrar);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.PanelSombra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.estiloBoton1);
            this.Controls.Add(this.txtContraseña);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.label3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmInicioSesion";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmInicioSesion";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.FrmInicioSesion_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnMini)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtContraseña;
        private EstiloBoton estiloBoton1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel PanelSombra;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconPictureBox ibtnCerrar;
        private FontAwesome.Sharp.IconPictureBox ibtnMini;
        private System.Windows.Forms.PictureBox btnHome;
    }
}