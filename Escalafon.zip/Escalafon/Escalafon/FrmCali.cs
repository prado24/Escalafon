﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escalafon
{
    public partial class FrmCali : Form
    {
        public FrmCali()
        {
            InitializeComponent();
        }
        private SqlConnection Conexion;
        private void FrmCali_Load(object sender, EventArgs e)
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            string Consultar = ("EXEC MostrarCali");
            Conexion.Open();
            SqlDataAdapter adaptador = new SqlDataAdapter(Consultar, Conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dgvUsuarios.DataSource = dt;
            DataView dtv = dt.DefaultView;
            dtv.Sort = "Calificacion DESC";
            dt = dtv.ToTable();
        }
    }
}
