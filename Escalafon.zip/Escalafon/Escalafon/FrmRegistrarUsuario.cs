﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escalafon
{
    public partial class FrmRegistrarUsuario : Form
    {
        public FrmRegistrarUsuario()
        {
            InitializeComponent();
        }
        public int currentCount = 0;
        private void estiloBoton1_Click(object sender, EventArgs e)
        {
            if (txtContraseña.Text == txtConfirmar.Text)
            {
                currentCount++;
                var Prueba = new UsuariosAdd();
                if (Prueba.Registrarusuarios(txtNombre.Text, txtUsuario.Text, txtContraseña.Text, txtPermisos.Text))
                {
                    FrmNotificacion n = new FrmNotificacion();
                    n.Show();
                    txtConfirmar.Text = "";
                    txtContraseña.Text = "";
                    txtNombre.Text = "";
                    txtUsuario.Text = "";
                    txtPermisos.Text = "";
                }
                else
                {
                    MessageBox.Show("No se pudo crear la cuenta");
                }
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void estiloBoton2_Click(object sender, EventArgs e)
        {
            //Close();
            //FrmInicioAdmin fa = new FrmInicioAdmin();
            //fa.Show();
            this.Hide();
        }
    }
}
