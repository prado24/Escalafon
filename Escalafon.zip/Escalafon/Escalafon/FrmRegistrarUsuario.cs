﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escalafon
{
    public partial class FrmRegistrarUsuario : Form
    {
        public FrmRegistrarUsuario()
        {
            InitializeComponent();
        }
        public int currentCount = 0;
        private void estiloBoton1_Click(object sender, EventArgs e)
        {
            
            if (txtNombre.Text != "" && txtUsuario.Text != "" && txtContraseña.Text != "" && txtConfirmar.Text != "" && txtPermisos.Text != "")
            {
                ComprobarUser();
                if (txtUsuario.Text != usuario)
                {
                    if (txtContraseña.Text == txtConfirmar.Text)
                    {
                        currentCount++;
                        var Prueba = new UsuariosAdd();
                        if (Prueba.Registrarusuarios(txtNombre.Text, txtUsuario.Text, txtContraseña.Text, txtPermisos.Text))
                        {
                            FrmNotificacion n = new FrmNotificacion();
                            n.Show();
                            txtConfirmar.Text = "";
                            txtContraseña.Text = "";
                            txtNombre.Text = "";
                            txtUsuario.Text = "";
                            txtPermisos.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("No se pudo crear la cuenta","",MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Contraseñas no iguales,"," vuelva a intentarlo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Este usuario ya se encuentra en uso,"," ingrese otro usuario",MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
            else
            {
                MessageBox.Show("Porfavor ingrese todos los campos","",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
        private SqlConnection Conexion;
        string usuario;
        public void ComprobarUser()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            //string con1 = "Select * From RUsuarios WHERE Usuario= " + txtUsuario.Text + "";
            //var Consultar4 = new SqlCommand(string.Format("Select Ususario from RUsuarios",txtUsuario.Text), Conexion);
            //Conexion.Open();
            //SqlDataReader reader2 = Consultar4.ExecuteReader();

            //if (reader2.Read())
            //{
            //    usuario = reader2["Usuario"].ToString();
            //}
            //reader2.Close();
            //Conexion.Close();}var Consultar4 = new SqlCommand(string.Format("Select Ususario from RUsuarios Where Usuario = '{0}'"), Conexion);
            var Consultar4 = new SqlCommand(string.Format("Select Usuario From RUsuarios Where Usuario = '{0}'", txtUsuario.Text), Conexion);
            Conexion.Open();
            SqlDataReader reader2 = Consultar4.ExecuteReader();

            if (reader2.Read())
            {
                usuario = reader2["Usuario"].ToString();
            }
            reader2.Close();
            Conexion.Close();
        }
    }
}
