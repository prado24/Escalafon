﻿namespace Escalafon
{
    partial class FrmInfoUsuarioAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDireccionT = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAsesorT = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAsesorR = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDesarrolloP = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtICertificados = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtIDiplomado = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtICursos = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDiplomado = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCertificaciones = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGrado = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCursos = new System.Windows.Forms.TextBox();
            this.lblCursos = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtId = new System.Windows.Forms.TextBox();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog3 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog4 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog5 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog6 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog7 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog8 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog9 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog10 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog11 = new System.Windows.Forms.OpenFileDialog();
            this.txtAnti = new System.Windows.Forms.TextBox();
            this.txtICursosST = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog12 = new System.Windows.Forms.OpenFileDialog();
            this.btnA13 = new Escalafon.EstiloBoton();
            this.txtGuardar = new Escalafon.EstiloBoton();
            this.btnA9 = new Escalafon.EstiloBoton();
            this.btnA10 = new Escalafon.EstiloBoton();
            this.btnA11 = new Escalafon.EstiloBoton();
            this.btnA2 = new Escalafon.EstiloBoton();
            this.btnA3 = new Escalafon.EstiloBoton();
            this.btnA5 = new Escalafon.EstiloBoton();
            this.btnA6 = new Escalafon.EstiloBoton();
            this.btnA4 = new Escalafon.EstiloBoton();
            this.btnA7 = new Escalafon.EstiloBoton();
            this.btnA8 = new Escalafon.EstiloBoton();
            this.estiloBoton2 = new Escalafon.EstiloBoton();
            this.openFileDialog13 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // txtDireccionT
            // 
            this.txtDireccionT.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDireccionT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDireccionT.Enabled = false;
            this.txtDireccionT.Location = new System.Drawing.Point(751, 278);
            this.txtDireccionT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDireccionT.Multiline = true;
            this.txtDireccionT.Name = "txtDireccionT";
            this.txtDireccionT.ReadOnly = true;
            this.txtDireccionT.Size = new System.Drawing.Size(150, 20);
            this.txtDireccionT.TabIndex = 79;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gainsboro;
            this.label16.Location = new System.Drawing.Point(572, 278);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(161, 20);
            this.label16.TabIndex = 78;
            this.label16.Text = "Dirección de Tesis:";
            // 
            // txtAsesorT
            // 
            this.txtAsesorT.BackColor = System.Drawing.Color.Gainsboro;
            this.txtAsesorT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAsesorT.Enabled = false;
            this.txtAsesorT.Location = new System.Drawing.Point(753, 234);
            this.txtAsesorT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAsesorT.Multiline = true;
            this.txtAsesorT.Name = "txtAsesorT";
            this.txtAsesorT.ReadOnly = true;
            this.txtAsesorT.Size = new System.Drawing.Size(150, 20);
            this.txtAsesorT.TabIndex = 76;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gainsboro;
            this.label15.Location = new System.Drawing.Point(546, 234);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(191, 20);
            this.label15.TabIndex = 75;
            this.label15.Text = "Asesor deTitulaciones:";
            // 
            // txtAsesorR
            // 
            this.txtAsesorR.BackColor = System.Drawing.Color.Gainsboro;
            this.txtAsesorR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAsesorR.Enabled = false;
            this.txtAsesorR.Location = new System.Drawing.Point(241, 274);
            this.txtAsesorR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAsesorR.Multiline = true;
            this.txtAsesorR.Name = "txtAsesorR";
            this.txtAsesorR.ReadOnly = true;
            this.txtAsesorR.Size = new System.Drawing.Size(150, 20);
            this.txtAsesorR.TabIndex = 73;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gainsboro;
            this.label14.Location = new System.Drawing.Point(37, 274);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(198, 20);
            this.label14.TabIndex = 72;
            this.label14.Text = "Asesor de Residencias:";
            // 
            // txtDesarrolloP
            // 
            this.txtDesarrolloP.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDesarrolloP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDesarrolloP.Enabled = false;
            this.txtDesarrolloP.Location = new System.Drawing.Point(753, 190);
            this.txtDesarrolloP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDesarrolloP.Multiline = true;
            this.txtDesarrolloP.Name = "txtDesarrolloP";
            this.txtDesarrolloP.ReadOnly = true;
            this.txtDesarrolloP.Size = new System.Drawing.Size(150, 20);
            this.txtDesarrolloP.TabIndex = 70;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gainsboro;
            this.label13.Location = new System.Drawing.Point(538, 196);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(205, 20);
            this.label13.TabIndex = 69;
            this.label13.Text = "Desarrollo de Proyectos:";
            // 
            // txtICertificados
            // 
            this.txtICertificados.BackColor = System.Drawing.Color.Gainsboro;
            this.txtICertificados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtICertificados.Enabled = false;
            this.txtICertificados.Location = new System.Drawing.Point(241, 231);
            this.txtICertificados.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtICertificados.Multiline = true;
            this.txtICertificados.Name = "txtICertificados";
            this.txtICertificados.ReadOnly = true;
            this.txtICertificados.Size = new System.Drawing.Size(150, 20);
            this.txtICertificados.TabIndex = 67;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gainsboro;
            this.label12.Location = new System.Drawing.Point(17, 231);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(218, 20);
            this.label12.TabIndex = 66;
            this.label12.Text = "Instructor de Certificados:";
            // 
            // txtIDiplomado
            // 
            this.txtIDiplomado.BackColor = System.Drawing.Color.Gainsboro;
            this.txtIDiplomado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIDiplomado.Enabled = false;
            this.txtIDiplomado.Location = new System.Drawing.Point(753, 152);
            this.txtIDiplomado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIDiplomado.Multiline = true;
            this.txtIDiplomado.Name = "txtIDiplomado";
            this.txtIDiplomado.ReadOnly = true;
            this.txtIDiplomado.Size = new System.Drawing.Size(150, 20);
            this.txtIDiplomado.TabIndex = 64;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(517, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(216, 20);
            this.label11.TabIndex = 63;
            this.label11.Text = "Instructor de Diplomados:";
            // 
            // txtICursos
            // 
            this.txtICursos.BackColor = System.Drawing.Color.Gainsboro;
            this.txtICursos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtICursos.Enabled = false;
            this.txtICursos.Location = new System.Drawing.Point(241, 158);
            this.txtICursos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtICursos.Multiline = true;
            this.txtICursos.Name = "txtICursos";
            this.txtICursos.ReadOnly = true;
            this.txtICursos.Size = new System.Drawing.Size(150, 20);
            this.txtICursos.TabIndex = 61;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(46, 155);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(189, 20);
            this.label10.TabIndex = 60;
            this.label10.Text = "Impartición de Cursos:";
            // 
            // txtDiplomado
            // 
            this.txtDiplomado.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDiplomado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiplomado.Enabled = false;
            this.txtDiplomado.Location = new System.Drawing.Point(753, 110);
            this.txtDiplomado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiplomado.Multiline = true;
            this.txtDiplomado.Name = "txtDiplomado";
            this.txtDiplomado.ReadOnly = true;
            this.txtDiplomado.Size = new System.Drawing.Size(150, 20);
            this.txtDiplomado.TabIndex = 58;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gainsboro;
            this.label9.Location = new System.Drawing.Point(629, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 20);
            this.label9.TabIndex = 57;
            this.label9.Text = "Diplomados:";
            // 
            // txtCertificaciones
            // 
            this.txtCertificaciones.BackColor = System.Drawing.Color.Gainsboro;
            this.txtCertificaciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCertificaciones.Enabled = false;
            this.txtCertificaciones.Location = new System.Drawing.Point(241, 115);
            this.txtCertificaciones.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCertificaciones.Multiline = true;
            this.txtCertificaciones.Name = "txtCertificaciones";
            this.txtCertificaciones.ReadOnly = true;
            this.txtCertificaciones.Size = new System.Drawing.Size(150, 20);
            this.txtCertificaciones.TabIndex = 55;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(102, 115);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(133, 20);
            this.label8.TabIndex = 54;
            this.label8.Text = "Certificaciones:";
            // 
            // txtGrado
            // 
            this.txtGrado.BackColor = System.Drawing.Color.Gainsboro;
            this.txtGrado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGrado.Enabled = false;
            this.txtGrado.Location = new System.Drawing.Point(753, 70);
            this.txtGrado.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGrado.Multiline = true;
            this.txtGrado.Name = "txtGrado";
            this.txtGrado.ReadOnly = true;
            this.txtGrado.Size = new System.Drawing.Size(150, 20);
            this.txtGrado.TabIndex = 53;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(573, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(164, 20);
            this.label7.TabIndex = 52;
            this.label7.Text = "Grado de Estudios:";
            // 
            // txtCursos
            // 
            this.txtCursos.BackColor = System.Drawing.Color.Gainsboro;
            this.txtCursos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCursos.Enabled = false;
            this.txtCursos.Location = new System.Drawing.Point(241, 71);
            this.txtCursos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCursos.Multiline = true;
            this.txtCursos.Name = "txtCursos";
            this.txtCursos.ReadOnly = true;
            this.txtCursos.Size = new System.Drawing.Size(150, 22);
            this.txtCursos.TabIndex = 48;
            // 
            // lblCursos
            // 
            this.lblCursos.AutoSize = true;
            this.lblCursos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCursos.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblCursos.Location = new System.Drawing.Point(165, 75);
            this.lblCursos.Name = "lblCursos";
            this.lblCursos.Size = new System.Drawing.Size(70, 20);
            this.lblCursos.TabIndex = 47;
            this.lblCursos.Text = "Cursos:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(129, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 45;
            this.label5.Text = "Antiguedad:";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txtId
            // 
            this.txtId.BackColor = System.Drawing.Color.Gainsboro;
            this.txtId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtId.Location = new System.Drawing.Point(633, 336);
            this.txtId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtId.Multiline = true;
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(150, 20);
            this.txtId.TabIndex = 105;
            this.txtId.Visible = false;
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // openFileDialog3
            // 
            this.openFileDialog3.FileName = "openFileDialog3";
            // 
            // openFileDialog4
            // 
            this.openFileDialog4.FileName = "openFileDialog4";
            // 
            // openFileDialog5
            // 
            this.openFileDialog5.FileName = "openFileDialog5";
            // 
            // openFileDialog6
            // 
            this.openFileDialog6.FileName = "openFileDialog6";
            // 
            // openFileDialog7
            // 
            this.openFileDialog7.FileName = "openFileDialog7";
            // 
            // openFileDialog8
            // 
            this.openFileDialog8.FileName = "openFileDialog8";
            // 
            // openFileDialog9
            // 
            this.openFileDialog9.FileName = "openFileDialog9";
            // 
            // openFileDialog10
            // 
            this.openFileDialog10.FileName = "openFileDialog10";
            // 
            // openFileDialog11
            // 
            this.openFileDialog11.FileName = "openFileDialog11";
            // 
            // txtAnti
            // 
            this.txtAnti.BackColor = System.Drawing.Color.Gainsboro;
            this.txtAnti.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAnti.Location = new System.Drawing.Point(241, 35);
            this.txtAnti.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAnti.Multiline = true;
            this.txtAnti.Name = "txtAnti";
            this.txtAnti.Size = new System.Drawing.Size(150, 20);
            this.txtAnti.TabIndex = 106;
            // 
            // txtICursosST
            // 
            this.txtICursosST.BackColor = System.Drawing.Color.Gainsboro;
            this.txtICursosST.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtICursosST.Enabled = false;
            this.txtICursosST.Location = new System.Drawing.Point(241, 196);
            this.txtICursosST.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtICursosST.Multiline = true;
            this.txtICursosST.Name = "txtICursosST";
            this.txtICursosST.ReadOnly = true;
            this.txtICursosST.Size = new System.Drawing.Size(150, 20);
            this.txtICursosST.TabIndex = 108;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(19, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 20);
            this.label1.TabIndex = 107;
            this.label1.Text = "Impartición de Cursos ST:";
            // 
            // openFileDialog12
            // 
            this.openFileDialog12.FileName = "openFileDialog12";
            // 
            // btnA13
            // 
            this.btnA13.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA13.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA13.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA13.BorderRadius = 2;
            this.btnA13.BorderSize = 0;
            this.btnA13.FlatAppearance.BorderSize = 0;
            this.btnA13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA13.ForeColor = System.Drawing.Color.Black;
            this.btnA13.Location = new System.Drawing.Point(398, 189);
            this.btnA13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA13.Name = "btnA13";
            this.btnA13.Size = new System.Drawing.Size(94, 29);
            this.btnA13.TabIndex = 109;
            this.btnA13.Text = "Agregar ";
            this.btnA13.TextColor = System.Drawing.Color.Black;
            this.btnA13.UseVisualStyleBackColor = false;
            this.btnA13.Click += new System.EventHandler(this.btnA13_Click);
            // 
            // txtGuardar
            // 
            this.txtGuardar.BackColor = System.Drawing.Color.MediumPurple;
            this.txtGuardar.BackgroundColor = System.Drawing.Color.MediumPurple;
            this.txtGuardar.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(90)))));
            this.txtGuardar.BorderRadius = 25;
            this.txtGuardar.BorderSize = 0;
            this.txtGuardar.FlatAppearance.BorderSize = 0;
            this.txtGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGuardar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.txtGuardar.Location = new System.Drawing.Point(862, 321);
            this.txtGuardar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGuardar.Name = "txtGuardar";
            this.txtGuardar.Size = new System.Drawing.Size(140, 44);
            this.txtGuardar.TabIndex = 103;
            this.txtGuardar.Text = "Aceptar";
            this.txtGuardar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.txtGuardar.UseVisualStyleBackColor = false;
            this.txtGuardar.Click += new System.EventHandler(this.txtGuardar_Click);
            // 
            // btnA9
            // 
            this.btnA9.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA9.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA9.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA9.BorderRadius = 2;
            this.btnA9.BorderSize = 0;
            this.btnA9.FlatAppearance.BorderSize = 0;
            this.btnA9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA9.ForeColor = System.Drawing.Color.Black;
            this.btnA9.Location = new System.Drawing.Point(398, 267);
            this.btnA9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA9.Name = "btnA9";
            this.btnA9.Size = new System.Drawing.Size(94, 26);
            this.btnA9.TabIndex = 102;
            this.btnA9.Text = "Agregar";
            this.btnA9.TextColor = System.Drawing.Color.Black;
            this.btnA9.UseVisualStyleBackColor = false;
            this.btnA9.Click += new System.EventHandler(this.btnA9_Click);
            // 
            // btnA10
            // 
            this.btnA10.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA10.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA10.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA10.BorderRadius = 2;
            this.btnA10.BorderSize = 0;
            this.btnA10.FlatAppearance.BorderSize = 0;
            this.btnA10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA10.ForeColor = System.Drawing.Color.Black;
            this.btnA10.Location = new System.Drawing.Point(908, 228);
            this.btnA10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA10.Name = "btnA10";
            this.btnA10.Size = new System.Drawing.Size(94, 26);
            this.btnA10.TabIndex = 101;
            this.btnA10.Text = "Agregar ";
            this.btnA10.TextColor = System.Drawing.Color.Black;
            this.btnA10.UseVisualStyleBackColor = false;
            this.btnA10.Click += new System.EventHandler(this.btnA10_Click);
            // 
            // btnA11
            // 
            this.btnA11.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA11.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA11.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA11.BorderRadius = 2;
            this.btnA11.BorderSize = 0;
            this.btnA11.FlatAppearance.BorderSize = 0;
            this.btnA11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA11.ForeColor = System.Drawing.Color.Black;
            this.btnA11.Location = new System.Drawing.Point(908, 271);
            this.btnA11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA11.Name = "btnA11";
            this.btnA11.Size = new System.Drawing.Size(94, 27);
            this.btnA11.TabIndex = 100;
            this.btnA11.Text = "Agregar ";
            this.btnA11.TextColor = System.Drawing.Color.Black;
            this.btnA11.UseVisualStyleBackColor = false;
            this.btnA11.Click += new System.EventHandler(this.btnA11_Click);
            // 
            // btnA2
            // 
            this.btnA2.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA2.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA2.BorderRadius = 2;
            this.btnA2.BorderSize = 0;
            this.btnA2.FlatAppearance.BorderSize = 0;
            this.btnA2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA2.ForeColor = System.Drawing.Color.Black;
            this.btnA2.Location = new System.Drawing.Point(909, 65);
            this.btnA2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(94, 28);
            this.btnA2.TabIndex = 99;
            this.btnA2.Text = "Agregar ";
            this.btnA2.TextColor = System.Drawing.Color.Black;
            this.btnA2.UseVisualStyleBackColor = false;
            this.btnA2.Click += new System.EventHandler(this.btnA2_Click);
            // 
            // btnA3
            // 
            this.btnA3.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA3.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA3.BorderRadius = 2;
            this.btnA3.BorderSize = 0;
            this.btnA3.FlatAppearance.BorderSize = 0;
            this.btnA3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA3.ForeColor = System.Drawing.Color.Black;
            this.btnA3.Location = new System.Drawing.Point(398, 108);
            this.btnA3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA3.Name = "btnA3";
            this.btnA3.Size = new System.Drawing.Size(94, 27);
            this.btnA3.TabIndex = 98;
            this.btnA3.Text = "Agregar ";
            this.btnA3.TextColor = System.Drawing.Color.Black;
            this.btnA3.UseVisualStyleBackColor = false;
            this.btnA3.Click += new System.EventHandler(this.btnA3_Click);
            // 
            // btnA5
            // 
            this.btnA5.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA5.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA5.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA5.BorderRadius = 2;
            this.btnA5.BorderSize = 0;
            this.btnA5.FlatAppearance.BorderSize = 0;
            this.btnA5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA5.ForeColor = System.Drawing.Color.Black;
            this.btnA5.Location = new System.Drawing.Point(398, 151);
            this.btnA5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA5.Name = "btnA5";
            this.btnA5.Size = new System.Drawing.Size(94, 29);
            this.btnA5.TabIndex = 97;
            this.btnA5.Text = "Agregar ";
            this.btnA5.TextColor = System.Drawing.Color.Black;
            this.btnA5.UseVisualStyleBackColor = false;
            this.btnA5.Click += new System.EventHandler(this.btnA5_Click);
            // 
            // btnA6
            // 
            this.btnA6.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA6.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA6.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA6.BorderRadius = 2;
            this.btnA6.BorderSize = 0;
            this.btnA6.FlatAppearance.BorderSize = 0;
            this.btnA6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA6.ForeColor = System.Drawing.Color.Black;
            this.btnA6.Location = new System.Drawing.Point(908, 186);
            this.btnA6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA6.Name = "btnA6";
            this.btnA6.Size = new System.Drawing.Size(94, 27);
            this.btnA6.TabIndex = 96;
            this.btnA6.Text = "Agregar";
            this.btnA6.TextColor = System.Drawing.Color.Black;
            this.btnA6.UseVisualStyleBackColor = false;
            this.btnA6.Click += new System.EventHandler(this.btnA6_Click);
            // 
            // btnA4
            // 
            this.btnA4.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA4.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA4.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA4.BorderRadius = 2;
            this.btnA4.BorderSize = 0;
            this.btnA4.FlatAppearance.BorderSize = 0;
            this.btnA4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA4.ForeColor = System.Drawing.Color.Black;
            this.btnA4.Location = new System.Drawing.Point(909, 106);
            this.btnA4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA4.Name = "btnA4";
            this.btnA4.Size = new System.Drawing.Size(94, 26);
            this.btnA4.TabIndex = 95;
            this.btnA4.Text = "Agregar ";
            this.btnA4.TextColor = System.Drawing.Color.Black;
            this.btnA4.UseVisualStyleBackColor = false;
            this.btnA4.Click += new System.EventHandler(this.btnA4_Click);
            // 
            // btnA7
            // 
            this.btnA7.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA7.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA7.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA7.BorderRadius = 2;
            this.btnA7.BorderSize = 0;
            this.btnA7.FlatAppearance.BorderSize = 0;
            this.btnA7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA7.ForeColor = System.Drawing.Color.Black;
            this.btnA7.Location = new System.Drawing.Point(398, 224);
            this.btnA7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA7.Name = "btnA7";
            this.btnA7.Size = new System.Drawing.Size(94, 27);
            this.btnA7.TabIndex = 94;
            this.btnA7.Text = "Agregar";
            this.btnA7.TextColor = System.Drawing.Color.Black;
            this.btnA7.UseVisualStyleBackColor = false;
            this.btnA7.Click += new System.EventHandler(this.btnA7_Click);
            // 
            // btnA8
            // 
            this.btnA8.BackColor = System.Drawing.Color.Gainsboro;
            this.btnA8.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.btnA8.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnA8.BorderRadius = 2;
            this.btnA8.BorderSize = 0;
            this.btnA8.FlatAppearance.BorderSize = 0;
            this.btnA8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA8.ForeColor = System.Drawing.Color.Black;
            this.btnA8.Location = new System.Drawing.Point(908, 146);
            this.btnA8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnA8.Name = "btnA8";
            this.btnA8.Size = new System.Drawing.Size(94, 28);
            this.btnA8.TabIndex = 93;
            this.btnA8.Text = "Agregar ";
            this.btnA8.TextColor = System.Drawing.Color.Black;
            this.btnA8.UseVisualStyleBackColor = false;
            this.btnA8.Click += new System.EventHandler(this.btnA8_Click);
            // 
            // estiloBoton2
            // 
            this.estiloBoton2.BackColor = System.Drawing.Color.Gainsboro;
            this.estiloBoton2.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.estiloBoton2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.estiloBoton2.BorderRadius = 2;
            this.estiloBoton2.BorderSize = 0;
            this.estiloBoton2.FlatAppearance.BorderSize = 0;
            this.estiloBoton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.estiloBoton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estiloBoton2.ForeColor = System.Drawing.Color.Black;
            this.estiloBoton2.Location = new System.Drawing.Point(398, 66);
            this.estiloBoton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.estiloBoton2.Name = "estiloBoton2";
            this.estiloBoton2.Size = new System.Drawing.Size(94, 28);
            this.estiloBoton2.TabIndex = 92;
            this.estiloBoton2.Text = "Agregar";
            this.estiloBoton2.TextColor = System.Drawing.Color.Black;
            this.estiloBoton2.UseVisualStyleBackColor = false;
            this.estiloBoton2.Click += new System.EventHandler(this.estiloBoton2_Click);
            // 
            // openFileDialog13
            // 
            this.openFileDialog13.FileName = "openFileDialog13";
            // 
            // FrmInfoUsuarioAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(1070, 389);
            this.Controls.Add(this.btnA13);
            this.Controls.Add(this.txtICursosST);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAnti);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.txtGuardar);
            this.Controls.Add(this.btnA9);
            this.Controls.Add(this.btnA10);
            this.Controls.Add(this.btnA11);
            this.Controls.Add(this.btnA2);
            this.Controls.Add(this.btnA3);
            this.Controls.Add(this.btnA5);
            this.Controls.Add(this.btnA6);
            this.Controls.Add(this.btnA4);
            this.Controls.Add(this.btnA7);
            this.Controls.Add(this.btnA8);
            this.Controls.Add(this.estiloBoton2);
            this.Controls.Add(this.txtDireccionT);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtAsesorT);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtAsesorR);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtDesarrolloP);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtICertificados);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtIDiplomado);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtICursos);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtDiplomado);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtCertificaciones);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtGrado);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCursos);
            this.Controls.Add(this.lblCursos);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmInfoUsuarioAdd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmInfoUsuarioAdd";
            this.Load += new System.EventHandler(this.FrmInfoUsuarioAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtDireccionT;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAsesorT;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAsesorR;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDesarrolloP;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtICertificados;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtIDiplomado;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtICursos;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDiplomado;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCertificaciones;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGrado;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCursos;
        private System.Windows.Forms.Label lblCursos;
        private System.Windows.Forms.Label label5;
        private EstiloBoton estiloBoton2;
        private EstiloBoton btnA8;
        private EstiloBoton btnA7;
        private EstiloBoton btnA4;
        private EstiloBoton btnA6;
        private EstiloBoton btnA5;
        private EstiloBoton btnA3;
        private EstiloBoton btnA2;
        private EstiloBoton btnA11;
        private EstiloBoton btnA10;
        private EstiloBoton btnA9;
        private EstiloBoton txtGuardar;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.OpenFileDialog openFileDialog3;
        private System.Windows.Forms.OpenFileDialog openFileDialog4;
        private System.Windows.Forms.OpenFileDialog openFileDialog5;
        private System.Windows.Forms.OpenFileDialog openFileDialog6;
        private System.Windows.Forms.OpenFileDialog openFileDialog7;
        private System.Windows.Forms.OpenFileDialog openFileDialog8;
        private System.Windows.Forms.OpenFileDialog openFileDialog9;
        private System.Windows.Forms.OpenFileDialog openFileDialog10;
        private System.Windows.Forms.OpenFileDialog openFileDialog11;
        private System.Windows.Forms.TextBox txtAnti;
        private EstiloBoton btnA13;
        private System.Windows.Forms.TextBox txtICursosST;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog12;
        private System.Windows.Forms.OpenFileDialog openFileDialog13;
    }
}