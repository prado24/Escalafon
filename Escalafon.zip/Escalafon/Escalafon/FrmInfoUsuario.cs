﻿using Escalafon.Model2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Escalafon
{
    public partial class FrmInfoUsuario : Form
    {
        public FrmInfoUsuario(FrmPrincipal.Datos info)
        {
            InitializeComponent();
            txtId.Text = info.id2.ToString();
        }

        private void FrmInfoUsuario_Load(object sender, EventArgs e)
        {
            Mostrar();
        }

        private void estiloBoton3_Click(object sender, EventArgs e)
        {
            //this.Hide();
            if (dgvArchivos.Rows.Count > 0)
            {
                int idcurso = int.Parse(dgvArchivos.Rows[dgvArchivos.CurrentRow.Index].Cells[0].Value.ToString());
                MessageBox.Show("" + idcurso);
            }
        }
        //Metodo para Mostrar archivos en dgv
        private SqlConnection Conexion;
        public void Mostrar()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            var Consultar = new SqlCommand(string.Format("Select id, realname, categoria From Archivos Where fkidusu = '{0}'", int.Parse(txtId.Text)), Conexion);
            Conexion.Open();
            //SqlDataAdapter adaptador = new SqlDataAdapter(Consultar, Conexion);
            SqlDataAdapter adaptador = new SqlDataAdapter(Consultar);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dgvArchivos.DataSource = dt;
        }

        private void estiloBoton2_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "C:\\";
            openFileDialog1.Filter = "Todos los Archivos (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtArchivo.Text = openFileDialog1.FileName;
            }
        }
        /* public int idcurso;
         public void llevar()
         {
             if (dgvArchivos.Rows.Count >= 0)
             {
                 idcurso = int.Parse(dgvArchivos.Rows[dgvArchivos.CurrentRow.Index].Cells[0].Value.ToString());
             }
         }*/
        public int id;
        private void estiloBoton1_Click(object sender, EventArgs e)
        {

            if (dgvArchivos.Rows.Count > 0)
            {
                id = int.Parse(dgvArchivos.Rows[dgvArchivos.CurrentRow.Index].Cells[0].Value.ToString());
                try
                {
                    byte[] nuevoDocumento = ObtenerBytesDelArchivo(); // Obtener el nuevo documento en formato byte[].

                    // Obtener el nuevo valor de realname desde el TextBox.
                    string nuevoRealName = openFileDialog1.SafeFileName;
                    //string nuevoName = txtNombre.Text;

                    // Establecer la conexión a la base de datos.
                    string connectionString = "Server=AFANTASMA\\MARIA;Database=Escalafon;User Id=sa;Password=Scaam7GG;";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();// Crear un comando para ejecutar el procedimiento almacenado.
                        using (SqlCommand command = new SqlCommand("ModificarArchivo", connection))
                        {
                            command.CommandType = CommandType.StoredProcedure;

                            // Pasar los parámetros al procedimiento almacenado.
                            command.Parameters.AddWithValue("@id", id);
                            command.Parameters.AddWithValue("@NuevoDoc", nuevoDocumento);
                            command.Parameters.AddWithValue("@NuevoRealName", nuevoRealName);
                            //command.Parameters.AddWithValue("@NuevoName", nuevoName);

                            // Ejecutar el procedimiento almacenado.
                            command.ExecuteNonQuery();

                            MessageBox.Show("Documento modificado correctamente.");
                        }
                    }

                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al modificar el documento: " + ex.Message);
                }

            }
        }
        private byte[] ObtenerBytesDelArchivo()
        {
            try
            {
                string rutaArchivo = txtArchivo.Text; // Obtener la ruta del archivo desde el TextBox.

                if (File.Exists(rutaArchivo))
                {
                    // Leer el archivo en un array de bytes.
                    byte[] bytesArchivo = File.ReadAllBytes(rutaArchivo);
                    return bytesArchivo;
                }
                else
                {
                    MessageBox.Show("El archivo no existe en la ubicación especificada.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los bytes del archivo: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void btnVer_Click(object sender, EventArgs e)
        {

        }

        private void ibtnVer_Click(object sender, EventArgs e)
        {
            if (dgvArchivos.Rows.Count > 0 && dgvArchivos.CurrentRow != null)
            {
                DataGridViewRow selectedRow = dgvArchivos.Rows[dgvArchivos.CurrentRow.Index];
                if (selectedRow.Cells["id"].Value != null)
                {
                    if (int.TryParse(selectedRow.Cells["id"].Value.ToString(), out int id))
                    {
                        using (Model2.EscalafonEntities5 db = new Model2.EscalafonEntities5())
                        {
                            var oDocuments = db.Archivos.Find(id);
                            string path = AppDomain.CurrentDomain.BaseDirectory;
                            string folder = path + "/temp/";
                            string fullFilePath = folder + oDocuments.realname;

                            if (!Directory.Exists(folder))
                                Directory.CreateDirectory(folder);

                            if (File.Exists(fullFilePath))
                            {
                                File.Delete(fullFilePath); // Elimina solo el archivo existente.
                            }

                            File.WriteAllBytes(fullFilePath, oDocuments.doc);

                            Process.Start(fullFilePath);
                        }
                    }
                    else
                    {
                        MessageBox.Show("El valor de ID no es válido.");
                    }
                }
                else
                {
                    MessageBox.Show("La celda ID no contiene un valor.");
                }
            }
            else
            {
                MessageBox.Show("No hay filas seleccionadas en el DataGridView.");
            }
        }
    }
}
