﻿namespace Escalafon
{
    partial class FrmCaliAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblComentario = new System.Windows.Forms.Label();
            this.txtComentario = new System.Windows.Forms.TextBox();
            this.txtICursosST = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAnti = new System.Windows.Forms.TextBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtDireccionT = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAsesorT = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAsesorR = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDesarrolloP = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtICertificados = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtIDiplomado = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtICursos = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDiplomado = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCertificaciones = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGrado = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCursos = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCerrar = new Escalafon.EstiloBoton();
            this.SuspendLayout();
            // 
            // lblComentario
            // 
            this.lblComentario.AutoSize = true;
            this.lblComentario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComentario.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblComentario.Location = new System.Drawing.Point(94, 374);
            this.lblComentario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblComentario.Name = "lblComentario";
            this.lblComentario.Size = new System.Drawing.Size(106, 20);
            this.lblComentario.TabIndex = 177;
            this.lblComentario.Text = "Comentario:";
            // 
            // txtComentario
            // 
            this.txtComentario.BackColor = System.Drawing.Color.Gainsboro;
            this.txtComentario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtComentario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComentario.Location = new System.Drawing.Point(98, 409);
            this.txtComentario.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtComentario.Multiline = true;
            this.txtComentario.Name = "txtComentario";
            this.txtComentario.ReadOnly = true;
            this.txtComentario.Size = new System.Drawing.Size(406, 55);
            this.txtComentario.TabIndex = 176;
            this.txtComentario.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtICursosST
            // 
            this.txtICursosST.BackColor = System.Drawing.Color.Gainsboro;
            this.txtICursosST.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtICursosST.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtICursosST.Location = new System.Drawing.Point(329, 239);
            this.txtICursosST.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtICursosST.Multiline = true;
            this.txtICursosST.Name = "txtICursosST";
            this.txtICursosST.ReadOnly = true;
            this.txtICursosST.Size = new System.Drawing.Size(175, 23);
            this.txtICursosST.TabIndex = 175;
            this.txtICursosST.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(70, 238);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 20);
            this.label1.TabIndex = 174;
            this.label1.Text = "Impartición de Cursos ST:";
            // 
            // txtAnti
            // 
            this.txtAnti.BackColor = System.Drawing.Color.Gainsboro;
            this.txtAnti.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAnti.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnti.Location = new System.Drawing.Point(329, 42);
            this.txtAnti.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtAnti.Multiline = true;
            this.txtAnti.Name = "txtAnti";
            this.txtAnti.ReadOnly = true;
            this.txtAnti.Size = new System.Drawing.Size(175, 23);
            this.txtAnti.TabIndex = 173;
            this.txtAnti.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtId
            // 
            this.txtId.BackColor = System.Drawing.Color.Gainsboro;
            this.txtId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtId.Location = new System.Drawing.Point(804, 386);
            this.txtId.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtId.Multiline = true;
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(175, 23);
            this.txtId.TabIndex = 172;
            this.txtId.Visible = false;
            // 
            // txtDireccionT
            // 
            this.txtDireccionT.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDireccionT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDireccionT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDireccionT.Location = new System.Drawing.Point(804, 335);
            this.txtDireccionT.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtDireccionT.Multiline = true;
            this.txtDireccionT.Name = "txtDireccionT";
            this.txtDireccionT.ReadOnly = true;
            this.txtDireccionT.Size = new System.Drawing.Size(175, 23);
            this.txtDireccionT.TabIndex = 171;
            this.txtDireccionT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gainsboro;
            this.label16.Location = new System.Drawing.Point(595, 335);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(161, 20);
            this.label16.TabIndex = 170;
            this.label16.Text = "Dirección de Tesis:";
            // 
            // txtAsesorT
            // 
            this.txtAsesorT.BackColor = System.Drawing.Color.Gainsboro;
            this.txtAsesorT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAsesorT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAsesorT.Location = new System.Drawing.Point(804, 286);
            this.txtAsesorT.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtAsesorT.Multiline = true;
            this.txtAsesorT.Name = "txtAsesorT";
            this.txtAsesorT.ReadOnly = true;
            this.txtAsesorT.Size = new System.Drawing.Size(175, 23);
            this.txtAsesorT.TabIndex = 169;
            this.txtAsesorT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gainsboro;
            this.label15.Location = new System.Drawing.Point(562, 286);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(191, 20);
            this.label15.TabIndex = 168;
            this.label15.Text = "Asesor deTitulaciones:";
            // 
            // txtAsesorR
            // 
            this.txtAsesorR.BackColor = System.Drawing.Color.Gainsboro;
            this.txtAsesorR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAsesorR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAsesorR.Location = new System.Drawing.Point(329, 334);
            this.txtAsesorR.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtAsesorR.Multiline = true;
            this.txtAsesorR.Name = "txtAsesorR";
            this.txtAsesorR.ReadOnly = true;
            this.txtAsesorR.Size = new System.Drawing.Size(175, 23);
            this.txtAsesorR.TabIndex = 167;
            this.txtAsesorR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gainsboro;
            this.label14.Location = new System.Drawing.Point(81, 334);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(198, 20);
            this.label14.TabIndex = 166;
            this.label14.Text = "Asesor de Residencias:";
            // 
            // txtDesarrolloP
            // 
            this.txtDesarrolloP.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDesarrolloP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDesarrolloP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesarrolloP.Location = new System.Drawing.Point(804, 235);
            this.txtDesarrolloP.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtDesarrolloP.Multiline = true;
            this.txtDesarrolloP.Name = "txtDesarrolloP";
            this.txtDesarrolloP.ReadOnly = true;
            this.txtDesarrolloP.Size = new System.Drawing.Size(175, 23);
            this.txtDesarrolloP.TabIndex = 165;
            this.txtDesarrolloP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gainsboro;
            this.label13.Location = new System.Drawing.Point(553, 242);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(205, 20);
            this.label13.TabIndex = 164;
            this.label13.Text = "Desarrollo de Proyectos:";
            // 
            // txtICertificados
            // 
            this.txtICertificados.BackColor = System.Drawing.Color.Gainsboro;
            this.txtICertificados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtICertificados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtICertificados.Location = new System.Drawing.Point(329, 284);
            this.txtICertificados.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtICertificados.Multiline = true;
            this.txtICertificados.Name = "txtICertificados";
            this.txtICertificados.ReadOnly = true;
            this.txtICertificados.Size = new System.Drawing.Size(175, 23);
            this.txtICertificados.TabIndex = 163;
            this.txtICertificados.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gainsboro;
            this.label12.Location = new System.Drawing.Point(71, 284);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(218, 20);
            this.label12.TabIndex = 162;
            this.label12.Text = "Instructor de Certificados:";
            // 
            // txtIDiplomado
            // 
            this.txtIDiplomado.BackColor = System.Drawing.Color.Gainsboro;
            this.txtIDiplomado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIDiplomado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDiplomado.Location = new System.Drawing.Point(804, 177);
            this.txtIDiplomado.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtIDiplomado.Multiline = true;
            this.txtIDiplomado.Name = "txtIDiplomado";
            this.txtIDiplomado.ReadOnly = true;
            this.txtIDiplomado.Size = new System.Drawing.Size(175, 23);
            this.txtIDiplomado.TabIndex = 161;
            this.txtIDiplomado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(528, 183);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(226, 20);
            this.label11.TabIndex = 160;
            this.label11.Text = "Instructor de Diplomaodos:";
            // 
            // txtICursos
            // 
            this.txtICursos.BackColor = System.Drawing.Color.Gainsboro;
            this.txtICursos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtICursos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtICursos.Location = new System.Drawing.Point(329, 199);
            this.txtICursos.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtICursos.Multiline = true;
            this.txtICursos.Name = "txtICursos";
            this.txtICursos.ReadOnly = true;
            this.txtICursos.Size = new System.Drawing.Size(175, 23);
            this.txtICursos.TabIndex = 159;
            this.txtICursos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(94, 196);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(189, 20);
            this.label10.TabIndex = 158;
            this.label10.Text = "Impartición de Cursos:";
            // 
            // txtDiplomado
            // 
            this.txtDiplomado.BackColor = System.Drawing.Color.Gainsboro;
            this.txtDiplomado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiplomado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiplomado.Location = new System.Drawing.Point(804, 125);
            this.txtDiplomado.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtDiplomado.Multiline = true;
            this.txtDiplomado.Name = "txtDiplomado";
            this.txtDiplomado.ReadOnly = true;
            this.txtDiplomado.Size = new System.Drawing.Size(175, 23);
            this.txtDiplomado.TabIndex = 157;
            this.txtDiplomado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gainsboro;
            this.label9.Location = new System.Drawing.Point(659, 129);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 20);
            this.label9.TabIndex = 156;
            this.label9.Text = "Diplomados:";
            // 
            // txtCertificaciones
            // 
            this.txtCertificaciones.BackColor = System.Drawing.Color.Gainsboro;
            this.txtCertificaciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCertificaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCertificaciones.Location = new System.Drawing.Point(329, 147);
            this.txtCertificaciones.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtCertificaciones.Multiline = true;
            this.txtCertificaciones.Name = "txtCertificaciones";
            this.txtCertificaciones.ReadOnly = true;
            this.txtCertificaciones.Size = new System.Drawing.Size(175, 23);
            this.txtCertificaciones.TabIndex = 155;
            this.txtCertificaciones.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(155, 147);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(133, 20);
            this.label8.TabIndex = 154;
            this.label8.Text = "Certificaciones:";
            // 
            // txtGrado
            // 
            this.txtGrado.BackColor = System.Drawing.Color.Gainsboro;
            this.txtGrado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrado.Location = new System.Drawing.Point(804, 63);
            this.txtGrado.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtGrado.Multiline = true;
            this.txtGrado.Name = "txtGrado";
            this.txtGrado.ReadOnly = true;
            this.txtGrado.Size = new System.Drawing.Size(175, 23);
            this.txtGrado.TabIndex = 153;
            this.txtGrado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(594, 66);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(164, 20);
            this.label7.TabIndex = 152;
            this.label7.Text = "Grado de Estudios:";
            // 
            // txtCursos
            // 
            this.txtCursos.BackColor = System.Drawing.Color.Gainsboro;
            this.txtCursos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCursos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCursos.Location = new System.Drawing.Point(329, 90);
            this.txtCursos.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtCursos.Multiline = true;
            this.txtCursos.Name = "txtCursos";
            this.txtCursos.ReadOnly = true;
            this.txtCursos.Size = new System.Drawing.Size(175, 25);
            this.txtCursos.TabIndex = 151;
            this.txtCursos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(219, 96);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 20);
            this.label6.TabIndex = 150;
            this.label6.Text = "Cursos:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(180, 38);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 149;
            this.label5.Text = "Antiguedad:";
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnCerrar.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnCerrar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnCerrar.BorderRadius = 25;
            this.btnCerrar.BorderSize = 0;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.ForeColor = System.Drawing.Color.Black;
            this.btnCerrar.Location = new System.Drawing.Point(881, 12);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(78, 31);
            this.btnCerrar.TabIndex = 179;
            this.btnCerrar.Text = "X";
            this.btnCerrar.TextColor = System.Drawing.Color.Black;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // FrmCaliAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(1048, 503);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.lblComentario);
            this.Controls.Add(this.txtComentario);
            this.Controls.Add(this.txtICursosST);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAnti);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.txtDireccionT);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtAsesorT);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtAsesorR);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtDesarrolloP);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtICertificados);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtIDiplomado);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtICursos);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtDiplomado);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtCertificaciones);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtGrado);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCursos);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Name = "FrmCaliAdmin";
            this.Text = "FrmCaliAdmin";
            this.Load += new System.EventHandler(this.FrmCaliAdmin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblComentario;
        private System.Windows.Forms.TextBox txtComentario;
        private System.Windows.Forms.TextBox txtICursosST;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAnti;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.TextBox txtDireccionT;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAsesorT;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAsesorR;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDesarrolloP;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtICertificados;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtIDiplomado;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtICursos;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDiplomado;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCertificaciones;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGrado;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCursos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private EstiloBoton btnCerrar;
    }
}