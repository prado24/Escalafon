﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escalafon
{
    public class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            //Application.Run(new FrmRegistrarUsuario());
            Application.Run(new FrmInicioSesion());
            //Application.Run(new FrmEvaluar());
            //Application.Run(new FrmInfoUsuarioAdd());
            //Application.Run(new FrmInfoUsuario());
            //Application.Run(new FrmPrincipal());
            //Application.Run(new FrmCali());
        }
    }
}
