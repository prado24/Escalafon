﻿namespace Escalafon
{
    partial class FrmInfoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtArchivo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtId = new System.Windows.Forms.TextBox();
            this.dgvArchivos = new System.Windows.Forms.DataGridView();
            this.ibtnVer = new Escalafon.EstiloBoton();
            this.estiloBoton1 = new Escalafon.EstiloBoton();
            this.estiloBoton2 = new Escalafon.EstiloBoton();
            this.btnEliminar = new Escalafon.EstiloBoton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvArchivos)).BeginInit();
            this.SuspendLayout();
            // 
            // txtArchivo
            // 
            this.txtArchivo.BackColor = System.Drawing.Color.Gainsboro;
            this.txtArchivo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtArchivo.Enabled = false;
            this.txtArchivo.Location = new System.Drawing.Point(172, 58);
            this.txtArchivo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtArchivo.Name = "txtArchivo";
            this.txtArchivo.ReadOnly = true;
            this.txtArchivo.Size = new System.Drawing.Size(338, 19);
            this.txtArchivo.TabIndex = 94;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(34, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 20);
            this.label6.TabIndex = 93;
            this.label6.Text = "Nuevo Archivo";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txtId
            // 
            this.txtId.BackColor = System.Drawing.Color.Gainsboro;
            this.txtId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtId.Location = new System.Drawing.Point(541, 378);
            this.txtId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtId.Multiline = true;
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(78, 22);
            this.txtId.TabIndex = 98;
            this.txtId.Visible = false;
            // 
            // dgvArchivos
            // 
            this.dgvArchivos.AllowUserToAddRows = false;
            this.dgvArchivos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvArchivos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvArchivos.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvArchivos.EnableHeadersVisualStyles = false;
            this.dgvArchivos.Location = new System.Drawing.Point(38, 117);
            this.dgvArchivos.Name = "dgvArchivos";
            this.dgvArchivos.ReadOnly = true;
            this.dgvArchivos.RowHeadersVisible = false;
            this.dgvArchivos.Size = new System.Drawing.Size(472, 283);
            this.dgvArchivos.TabIndex = 99;
            // 
            // ibtnVer
            // 
            this.ibtnVer.BackColor = System.Drawing.Color.MediumOrchid;
            this.ibtnVer.BackgroundColor = System.Drawing.Color.MediumOrchid;
            this.ibtnVer.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.ibtnVer.BorderRadius = 20;
            this.ibtnVer.BorderSize = 0;
            this.ibtnVer.FlatAppearance.BorderSize = 0;
            this.ibtnVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnVer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnVer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.ibtnVer.Location = new System.Drawing.Point(529, 184);
            this.ibtnVer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ibtnVer.Name = "ibtnVer";
            this.ibtnVer.Size = new System.Drawing.Size(106, 37);
            this.ibtnVer.TabIndex = 103;
            this.ibtnVer.Text = "Ver";
            this.ibtnVer.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.ibtnVer.UseVisualStyleBackColor = false;
            this.ibtnVer.Click += new System.EventHandler(this.ibtnVer_Click);
            // 
            // estiloBoton1
            // 
            this.estiloBoton1.BackColor = System.Drawing.Color.MediumOrchid;
            this.estiloBoton1.BackgroundColor = System.Drawing.Color.MediumOrchid;
            this.estiloBoton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.estiloBoton1.BorderRadius = 20;
            this.estiloBoton1.BorderSize = 0;
            this.estiloBoton1.FlatAppearance.BorderSize = 0;
            this.estiloBoton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.estiloBoton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estiloBoton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.estiloBoton1.Location = new System.Drawing.Point(529, 117);
            this.estiloBoton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.estiloBoton1.Name = "estiloBoton1";
            this.estiloBoton1.Size = new System.Drawing.Size(106, 37);
            this.estiloBoton1.TabIndex = 96;
            this.estiloBoton1.Text = "Modificar";
            this.estiloBoton1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.estiloBoton1.UseVisualStyleBackColor = false;
            this.estiloBoton1.Click += new System.EventHandler(this.estiloBoton1_Click);
            // 
            // estiloBoton2
            // 
            this.estiloBoton2.BackColor = System.Drawing.Color.MediumOrchid;
            this.estiloBoton2.BackgroundColor = System.Drawing.Color.MediumOrchid;
            this.estiloBoton2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.estiloBoton2.BorderRadius = 20;
            this.estiloBoton2.BorderSize = 0;
            this.estiloBoton2.FlatAppearance.BorderSize = 0;
            this.estiloBoton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.estiloBoton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estiloBoton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.estiloBoton2.Location = new System.Drawing.Point(529, 54);
            this.estiloBoton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.estiloBoton2.Name = "estiloBoton2";
            this.estiloBoton2.Size = new System.Drawing.Size(106, 37);
            this.estiloBoton2.TabIndex = 95;
            this.estiloBoton2.Text = "Agregar";
            this.estiloBoton2.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.estiloBoton2.UseVisualStyleBackColor = false;
            this.estiloBoton2.Click += new System.EventHandler(this.estiloBoton2_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnEliminar.BackgroundColor = System.Drawing.Color.MediumOrchid;
            this.btnEliminar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnEliminar.BorderRadius = 20;
            this.btnEliminar.BorderSize = 0;
            this.btnEliminar.FlatAppearance.BorderSize = 0;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnEliminar.Location = new System.Drawing.Point(529, 254);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(106, 37);
            this.btnEliminar.TabIndex = 104;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // FrmInfoUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(674, 463);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.ibtnVer);
            this.Controls.Add(this.dgvArchivos);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.estiloBoton1);
            this.Controls.Add(this.estiloBoton2);
            this.Controls.Add(this.txtArchivo);
            this.Controls.Add(this.label6);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmInfoUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmInfoUsuario";
            this.Load += new System.EventHandler(this.FrmInfoUsuario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvArchivos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private EstiloBoton estiloBoton2;
        private System.Windows.Forms.TextBox txtArchivo;
        private System.Windows.Forms.Label label6;
        private EstiloBoton estiloBoton1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.DataGridView dgvArchivos;
        private EstiloBoton ibtnVer;
        private EstiloBoton btnEliminar;
    }
}