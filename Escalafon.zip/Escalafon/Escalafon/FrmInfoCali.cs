﻿using Escalafon.Model2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using FontAwesome.Sharp;
using System.Runtime.InteropServices;

namespace Escalafon
{
    public partial class FrmInfoCali : Form
    {
        public int Califi;
        public int r, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15;

        private void ibtnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnComentario_Click(object sender, EventArgs e)
        {

        }

        private void btnReinicar_Click(object sender, EventArgs e)
        {
            lblCalificacion.Text = "";
            r = 0; r2 = 0; r3 = 0; r4 = 0; r5 = 0; r6 = 0; r7 = 0; r8 = 0; r9 = 0; r10 = 0;
            r11 = 0; r12 = 0; r13 = 0; r14 = 0; r15 = 0;
            Califi = 0;
            cbDPI.Checked = false;
            cbAntiguedad.Checked = false;
            cbDTesis.Checked = false;
            cmbICursos.SelectedItem = null;
            npdICursos.Value = 0;
            cmbCursos.SelectedItem = null;
            cmbGrado.SelectedItem = null;
            npdCrussoST.Value = 0;
            npdAResidencias.Value = 0;
            npdATitulaciones.Value = 0;
            npdICertificados.Value = 0;
            npdIDiplomados.Value = 0;
            npdCertificaciones.Value = 0;
            npdDiplomado.Value = 0;
        }

        public FrmInfoCali(FrmEvaluar.Datos info)
        {
            InitializeComponent();
            txtId.Text = info.id.ToString();
        }
        private SqlConnection Conexion;
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            var Consultar = new SqlCommand(String.Format("Update Cali Set calificacion = '{0}' Where Fkidusu = '{1}'", int.Parse(lblCalificacion.Text), int.Parse(txtId.Text)), Conexion);
            var Consultar2 = new SqlCommand(String.Format("Update Calificacion Set gradoe = '{0}', antiguedad = '{1}', cursos = '{2}', certificaciones = '{3}', diplomados = '{4}', imparticioncst = '{5}', instructord = '{6}', imparticionc = '{7}', instructorcer = '{8}', desarrollopi = '{9}', asesorre = '{10}', asesort = '{11}', direcciont = '{12}'  Where fkidusu = '{13}'", r,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13, int.Parse(txtId.Text)), Conexion);
            var Consultar3 = new SqlCommand(String.Format("Update Comentarios Set Comentario = '{0}' Where fkidusu = '{1}'", txtComentario.Text, int.Parse(txtId.Text)),Conexion);
            Conexion.Open();
            Consultar.ExecuteNonQuery();
            Consultar2.ExecuteNonQuery();
            Consultar3.ExecuteNonQuery();
            Conexion.Close();
            MessageBox.Show("Se guardo Correctamente","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //FrmEvaluar fe = new FrmEvaluar();
            //fe.Show();
            //this.Hide();
            this.Close();
        }
        

        private void FrmInfoCali_Load(object sender, EventArgs e)
        {
            Mostrar();
            //MostrarFecha();
            Antiguedad();
        }
        
        public void Mostrar()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            var Consultar = new SqlCommand(string.Format("Select id, realname, categoria From Archivos Where fkidusu = '{0}'", int.Parse(txtId.Text)), Conexion);
            Conexion.Open();
            SqlDataAdapter adaptador = new SqlDataAdapter(Consultar);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dgvInfoU.DataSource = dt;
        }
        public void Antiguedad()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            var Consultar4 = new SqlCommand(string.Format("Select Años from Anti Where fkidusu = '{0}'", int.Parse(txtId.Text)), Conexion);
            Conexion.Open();
            SqlDataReader reader2 = Consultar4.ExecuteReader();
            if (reader2.Read())
            {
                txtAntiguedad.Text = reader2["Años"].ToString();
            }
            Conexion.Close();
        }
        public void MostrarFecha()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            var Consultar = new SqlCommand(string.Format("Select Años From Anti Where Fkidusu = '{0}'", int.Parse(txtId.Text)), Conexion);
            Conexion.Open();
            SqlDataAdapter adaptador = new SqlDataAdapter(Consultar);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dgvFecha.DataSource = dt;
        }

        private void txtVer_Click(object sender, EventArgs e)
        {
            if (dgvInfoU.Rows.Count > 0)
            {
                int id = int.Parse(dgvInfoU.Rows[dgvInfoU.CurrentRow.Index].Cells[0].Value.ToString());
                //using (Model.EscalafonEntities4 db = new Model.EscalafonEntities4())
                using (Model2.EscalafonEntities5 db = new Model2.EscalafonEntities5())
                {
                    var Document = db.Archivos.Find(id);

                    string path = AppDomain.CurrentDomain.BaseDirectory;
                    string folder = path + "/temp/";
                    string fullfilepath = folder + Document.realname;

                    if (!Directory.Exists(folder))
                    {
                        Directory.CreateDirectory(folder);
                    }

                    if (File.Exists(folder))
                    {
                        Directory.Delete(folder);
                    }
                    File.WriteAllBytes(fullfilepath, Document.doc);

                    Process.Start(fullfilepath);
                }
            }
            if (!(dgvInfoU.Rows.Count > 0))
            {
                MessageBox.Show("No se encuentra ningun archivo","", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            //Condicion para saber si tiene fecha de antiguedad
            if (cbAntiguedad.Checked == true)
            {
                 int id = int.Parse(dgvFecha.Rows[dgvFecha.CurrentRow.Index].Cells[0].Value.ToString());
                 r = id * 10;
            }
            if(cbAntiguedad.Checked == false)
            {
                r = 0;
            }
            //Condicionar si es que tiene certificados el usuario
            if (npdCertificaciones.Value > 0)
            {
                r2 = int.Parse(npdCertificaciones.Value.ToString()) * 20;

            }
            //Condicion si tiene diplomados el usuario
            if (npdDiplomado.Value > 0)
            {
                //MessageBox.Show((10 * npdDiplomado.Value).ToString());
                r3 = int.Parse((10 * npdDiplomado.Value).ToString());

            }
            //Condicion si tiene imparticiones de cursos st
            if (npdCrussoST.Value > 0)
            {
                //MessageBox.Show((20 * npdCrussoST.Value).ToString());
                r4 = int.Parse((20 * npdCrussoST.Value).ToString());
            }
            //Condicion para saber si el usuario tiene Imparticion de cursos
            if (npdICursos.Value > 0 && cmbICursos.Text == "Mayor a 30hrs")
            {
                //MessageBox.Show((15 * npdICursos.Value).ToString());
                r5 = int.Parse((15 * npdICursos.Value).ToString());
            }
            if (npdICursos.Value > 0 && cmbICursos.Text == "Menor a 30hrs")
            {
                //MessageBox.Show((15 * npdICursos.Value).ToString());
                r5 = int.Parse((7 * npdICursos.Value).ToString());
            }
            //Condicion para saber si el usuario fue instructor de certificados
            if (npdICertificados.Value > 0)
            {
                //MessageBox.Show((30 * npdICertificados.Value).ToString());
                r6 = int.Parse((30 * npdICertificados.Value).ToString());
            }
            //COndicion para saber si el usuario desarrollo de proyecto investigacion}
            if (cbDPI.Checked == true)
            {
                //MessageBox.Show((10).ToString());
                r7 = int.Parse((10).ToString());
            }
            //Condicion para saber si tiene un archivo de asesor de residencias
            if (npdAResidencias.Value > 0)
            {
                //MessageBox.Show((1 * npdAResidencias.Value).ToString());
                r8 = int.Parse((1 * npdAResidencias.Value).ToString());
            }
            //Condicion para saber si tiene un archivo de asesor de titulaciones
            if (npdATitulaciones.Value > 0)
            {
                //MessageBox.Show((1 * npdATitulaciones.Value).ToString());
                r9 = int.Parse((1 * npdATitulaciones.Value).ToString());
            }
            //Condicion para saber si el usuario tiene un documento de asesor de tesis
            if (cbDTesis.Checked == true)
            {
                //MessageBox.Show((10).ToString());
                r10 = int.Parse((10).ToString());
            }
            //Condicion para saber si el usuario tiene certificado de doctorado
            if (cmbGrado.Text == "Doctorado")
            {
                //MessageBox.Show((30).ToString());
                r11 = int.Parse((30).ToString());
            }
            //Condicion para saber si el usuario tiene certificados de Maestria
            if (cmbGrado.Text == "Maestria")
            {
                //MessageBox.Show((20).ToString());
                //r12 = int.Parse((20).ToString());
                r11 = int.Parse((20).ToString());
            }
            //Condicion para saber si el usuario tiene certificados de Licenciatura
            if (cmbGrado.Text == "Licenciatura")
            {
                // MessageBox.Show((10).ToString());
                //r13 = int.Parse((10).ToString());
                r11 = int.Parse((10).ToString());
            }
            //Condicion para saber si el usuario tiene cursos de más de 30hrs
            if (cmbCursos.Text == "Mayor a 30hrs")
            {
                //MessageBox.Show((2).ToString());
                //r14 = int.Parse((2).ToString());
                r12 = int.Parse((2).ToString());
            }
            //Condicion para saber si el usuario tiene cursos de menos de 30hrs
            if (cmbCursos.Text == "Menor a 30hrs")
            {
                //MessageBox.Show((1).ToString());
                //r15 = int.Parse((1).ToString());
                r12 = int.Parse((1).ToString());
            }
            //Condicion para saber si el usuario fue instructor de diplomados
            if (npdIDiplomados.Value > 0)
            {
                //MessageBox.Show((1).ToString());
                //r15 = int.Parse((1).ToString());
                r13 = int.Parse((20 * npdIDiplomados.Value).ToString());
            }
            //Califi = r + r2 + r3 + r4 + r5 + r6 + r7 + r8 +r9 + r10 + r11 + r12 + r13 + r14 + r15;
            Califi = r + r2 + r3 + r4 + r5 + r6 + r7 + r8 + r9 + r10 + r11 + r12 + r13;
            lblCalificacion.Text = Califi.ToString();
        }
        public void TodaslassCalificaciones()
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
