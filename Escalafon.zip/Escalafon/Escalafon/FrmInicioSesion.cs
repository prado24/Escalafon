﻿using Escalafon.Model2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Escalafon.FrmEvaluar;

namespace Escalafon
{
    public partial class FrmInicioSesion : Form
    {
        public FrmInicioSesion()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void estiloBoton1_Click(object sender, EventArgs e)
        {
            var Prueba = new FrmAutenticacion();
            if (Prueba.Autorizar(txtUsuario.Text, txtContraseña.Text) >0)
            {
                FrmPAdmin pa = new FrmPAdmin();
                pa.Show();
                //FrmInicioAdmin fa = new FrmInicioAdmin();
                //fa.Show();
                this.Hide();
                //MessageBox.Show("Bienvenido " + txtUsuario.Text + "Rol: Admin");
                txtContraseña.Text = "";
                txtUsuario.Text = "";

            }

            else if (Prueba.Autorizar2(txtUsuario.Text, txtContraseña.Text) > 0)
            {
                Mostrar();
                //FrmInicioUser su = new FrmInicioUser(info);
                FrmPrincipal pr = new FrmPrincipal(info);

                //FrmInfoUsuarioAdd fadd = new FrmInfoUsuarioAdd(info);
                //su.Show();
                pr.Show();
                this.Hide();
                txtContraseña.Text = "";
                txtUsuario.Text = "";

            }
            else
            {
                MessageBox.Show("Usuario o contraseñas equivocados");
            }
        }
        private void FrmInicioSesion_Load(object sender, EventArgs e)
        {
            
        }
        public struct Datos
        {
            public int id;
        }
        private SqlConnection Conexion;
        Datos info;
        public void Mostrar()
        {
           
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            //string con1 = "Select * From RUsuarios WHERE Usuario= " + txtUsuario.Text + "";
            var Consultar3 = new SqlCommand(string.Format("Select Idusu From RUsuarios Where Usuario = '{0}' and Contraseña = '{1}' and Rol = 'user'", txtUsuario.Text, txtContraseña.Text), Conexion);
            Conexion.Open();
            SqlDataReader reader2 = Consultar3.ExecuteReader();
            if(reader2.Read())
            {
                info = new Datos();
                //txtId.Text = reader2["Idusu"].ToString();
                info.id = int.Parse(reader2["Idusu"].ToString());

            }
            Conexion.Close();
        }

        private void txtP_Click(object sender, EventArgs e)
        {
            
        }

        private void ibtnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ibtnMini_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void txtUsuario_Enter(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "USUARIO")
            {
                txtUsuario.Text = "";
                txtUsuario.ForeColor = Color.LightGray;
            }
        }

        private void txtUsuario_Leave(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "")
            {
                txtUsuario.Text = "USUARIO";
                txtUsuario.ForeColor = Color.DimGray;
            }
        }

        private void txtContraseña_Enter(object sender, EventArgs e)
        {
            if (txtContraseña.Text == "CONTRASEÑA")
            {
                txtContraseña.Text = "";
                txtContraseña.ForeColor = Color.LightGray;
                txtContraseña.UseSystemPasswordChar = true;
            }
        }

        private void txtContraseña_Leave(object sender, EventArgs e)
        {
            if (txtContraseña.Text == "")
            {
                txtContraseña.Text = "CONTRASEÑA";
                txtContraseña.ForeColor = Color.DimGray;
                txtContraseña.UseSystemPasswordChar = false;
            }
        }

        private void txtContraseña_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                e.Handled = true;
                var Prueba = new FrmAutenticacion();
                if (Prueba.Autorizar(txtUsuario.Text, txtContraseña.Text) > 0)
                {
                    FrmPAdmin pa = new FrmPAdmin();
                    pa.Show();
                    //FrmInicioAdmin fa = new FrmInicioAdmin();
                    //fa.Show();
                    this.Hide();
                    //MessageBox.Show("Bienvenido " + txtUsuario.Text + "Rol: Admin");
                    txtContraseña.Text = "";
                    txtUsuario.Text = "";

                }

                else if (Prueba.Autorizar2(txtUsuario.Text, txtContraseña.Text) > 0)
                {
                    Mostrar();
                    //FrmInicioUser su = new FrmInicioUser(info);
                    FrmPrincipal pr = new FrmPrincipal(info);

                    //FrmInfoUsuarioAdd fadd = new FrmInfoUsuarioAdd(info);
                    //su.Show();
                    pr.Show();
                    this.Hide();
                    txtContraseña.Text = "";
                    txtUsuario.Text = "";

                }
                else
                {
                    MessageBox.Show("Usuario o contraseñas equivocados");
                }
            }
        }
        private bool mostrarPassword = false;
        private void ibtnMostrar_Click(object sender, EventArgs e)
        {
            mostrarPassword = !mostrarPassword;

            if (mostrarPassword)
            {
                txtContraseña.UseSystemPasswordChar = false;
                ibtnMostrar.IconChar = FontAwesome.Sharp.IconChar.EyeSlash;
            }
            else
            {
                txtContraseña.UseSystemPasswordChar = true;
                ibtnMostrar.IconChar = FontAwesome.Sharp.IconChar.Eye;
            }
        }
    }
}
