﻿namespace Escalafon
{
    partial class FrmPAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPAdmin));
            this.pSalvar = new System.Windows.Forms.Panel();
            this.lblFecha = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblHora = new System.Windows.Forms.Label();
            this.PanelEscritorio = new System.Windows.Forms.Panel();
            this.PanelSombra = new System.Windows.Forms.Panel();
            this.tHora = new System.Windows.Forms.Timer(this.components);
            this.ibtnMinimizar = new FontAwesome.Sharp.IconPictureBox();
            this.ibtnMaximizar = new FontAwesome.Sharp.IconPictureBox();
            this.btnHome = new System.Windows.Forms.PictureBox();
            this.ibtnCerrar = new FontAwesome.Sharp.IconPictureBox();
            this.lblHome = new System.Windows.Forms.Label();
            this.iconHome = new FontAwesome.Sharp.IconPictureBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.ibtnCalificaciones = new FontAwesome.Sharp.IconButton();
            this.ibtnRegistrar = new FontAwesome.Sharp.IconButton();
            this.PanelLogo = new System.Windows.Forms.Panel();
            this.PanelBarraTitulo = new System.Windows.Forms.Panel();
            this.PanelMenu = new System.Windows.Forms.Panel();
            this.ibtnEliminar = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelEscritorio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconHome)).BeginInit();
            this.PanelLogo.SuspendLayout();
            this.PanelBarraTitulo.SuspendLayout();
            this.PanelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pSalvar
            // 
            this.pSalvar.Location = new System.Drawing.Point(220, 84);
            this.pSalvar.Name = "pSalvar";
            this.pSalvar.Size = new System.Drawing.Size(1011, 434);
            this.pSalvar.TabIndex = 3;
            // 
            // lblFecha
            // 
            this.lblFecha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblFecha.Location = new System.Drawing.Point(352, 375);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(62, 25);
            this.lblFecha.TabIndex = 2;
            this.lblFecha.Text = "Ínicio";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(404, 154);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 198);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblHora
            // 
            this.lblHora.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHora.AutoSize = true;
            this.lblHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.ForeColor = System.Drawing.Color.MediumPurple;
            this.lblHora.Location = new System.Drawing.Point(445, 74);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(28, 42);
            this.lblHora.TabIndex = 0;
            this.lblHora.Text = ".";
            // 
            // PanelEscritorio
            // 
            this.PanelEscritorio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.PanelEscritorio.Controls.Add(this.lblFecha);
            this.PanelEscritorio.Controls.Add(this.pictureBox1);
            this.PanelEscritorio.Controls.Add(this.lblHora);
            this.PanelEscritorio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelEscritorio.Location = new System.Drawing.Point(220, 84);
            this.PanelEscritorio.Name = "PanelEscritorio";
            this.PanelEscritorio.Size = new System.Drawing.Size(1014, 513);
            this.PanelEscritorio.TabIndex = 7;
            // 
            // PanelSombra
            // 
            this.PanelSombra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(24)))), ((int)(((byte)(58)))));
            this.PanelSombra.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelSombra.Location = new System.Drawing.Point(220, 75);
            this.PanelSombra.Name = "PanelSombra";
            this.PanelSombra.Size = new System.Drawing.Size(1014, 9);
            this.PanelSombra.TabIndex = 6;
            // 
            // tHora
            // 
            this.tHora.Enabled = true;
            this.tHora.Tick += new System.EventHandler(this.tHora_Tick_1);
            // 
            // ibtnMinimizar
            // 
            this.ibtnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ibtnMinimizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.ibtnMinimizar.ForeColor = System.Drawing.Color.MediumPurple;
            this.ibtnMinimizar.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            this.ibtnMinimizar.IconColor = System.Drawing.Color.MediumPurple;
            this.ibtnMinimizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnMinimizar.IconSize = 27;
            this.ibtnMinimizar.Location = new System.Drawing.Point(909, 0);
            this.ibtnMinimizar.Name = "ibtnMinimizar";
            this.ibtnMinimizar.Size = new System.Drawing.Size(27, 38);
            this.ibtnMinimizar.TabIndex = 4;
            this.ibtnMinimizar.TabStop = false;
            this.ibtnMinimizar.Click += new System.EventHandler(this.ibtnMinimizar_Click_1);
            // 
            // ibtnMaximizar
            // 
            this.ibtnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ibtnMaximizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.ibtnMaximizar.ForeColor = System.Drawing.Color.MediumPurple;
            this.ibtnMaximizar.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            this.ibtnMaximizar.IconColor = System.Drawing.Color.MediumPurple;
            this.ibtnMaximizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnMaximizar.IconSize = 27;
            this.ibtnMaximizar.Location = new System.Drawing.Point(942, 3);
            this.ibtnMaximizar.Name = "ibtnMaximizar";
            this.ibtnMaximizar.Size = new System.Drawing.Size(27, 27);
            this.ibtnMaximizar.TabIndex = 3;
            this.ibtnMaximizar.TabStop = false;
            this.ibtnMaximizar.Click += new System.EventHandler(this.ibtnMaximizar_Click_1);
            // 
            // btnHome
            // 
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.Location = new System.Drawing.Point(57, 12);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(100, 112);
            this.btnHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnHome.TabIndex = 0;
            this.btnHome.TabStop = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click_1);
            // 
            // ibtnCerrar
            // 
            this.ibtnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ibtnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.ibtnCerrar.ForeColor = System.Drawing.Color.MediumPurple;
            this.ibtnCerrar.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.ibtnCerrar.IconColor = System.Drawing.Color.MediumPurple;
            this.ibtnCerrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCerrar.IconSize = 27;
            this.ibtnCerrar.Location = new System.Drawing.Point(975, 3);
            this.ibtnCerrar.Name = "ibtnCerrar";
            this.ibtnCerrar.Size = new System.Drawing.Size(27, 27);
            this.ibtnCerrar.TabIndex = 2;
            this.ibtnCerrar.TabStop = false;
            this.ibtnCerrar.Click += new System.EventHandler(this.ibtnCerrar_Click_1);
            // 
            // lblHome
            // 
            this.lblHome.AutoSize = true;
            this.lblHome.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblHome.Location = new System.Drawing.Point(61, 35);
            this.lblHome.Name = "lblHome";
            this.lblHome.Size = new System.Drawing.Size(46, 20);
            this.lblHome.TabIndex = 1;
            this.lblHome.Text = "Ínicio";
            // 
            // iconHome
            // 
            this.iconHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.iconHome.ForeColor = System.Drawing.Color.MediumPurple;
            this.iconHome.IconChar = FontAwesome.Sharp.IconChar.HomeLg;
            this.iconHome.IconColor = System.Drawing.Color.MediumPurple;
            this.iconHome.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconHome.IconSize = 34;
            this.iconHome.Location = new System.Drawing.Point(21, 26);
            this.iconHome.Name = "iconHome";
            this.iconHome.Size = new System.Drawing.Size(34, 46);
            this.iconHome.TabIndex = 0;
            this.iconHome.TabStop = false;
            // 
            // txtId
            // 
            this.txtId.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txtId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtId.Location = new System.Drawing.Point(39, 348);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 19);
            this.txtId.TabIndex = 4;
            this.txtId.Visible = false;
            // 
            // ibtnCalificaciones
            // 
            this.ibtnCalificaciones.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnCalificaciones.FlatAppearance.BorderSize = 0;
            this.ibtnCalificaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnCalificaciones.ForeColor = System.Drawing.Color.Gainsboro;
            this.ibtnCalificaciones.IconChar = FontAwesome.Sharp.IconChar.ChartColumn;
            this.ibtnCalificaciones.IconColor = System.Drawing.Color.Gainsboro;
            this.ibtnCalificaciones.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCalificaciones.IconSize = 32;
            this.ibtnCalificaciones.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCalificaciones.Location = new System.Drawing.Point(0, 200);
            this.ibtnCalificaciones.Name = "ibtnCalificaciones";
            this.ibtnCalificaciones.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.ibtnCalificaciones.Size = new System.Drawing.Size(220, 60);
            this.ibtnCalificaciones.TabIndex = 2;
            this.ibtnCalificaciones.Text = "Calificaciones";
            this.ibtnCalificaciones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnCalificaciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ibtnCalificaciones.UseVisualStyleBackColor = true;
            this.ibtnCalificaciones.Click += new System.EventHandler(this.ibtnCalificaciones_Click_1);
            // 
            // ibtnRegistrar
            // 
            this.ibtnRegistrar.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnRegistrar.FlatAppearance.BorderSize = 0;
            this.ibtnRegistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnRegistrar.ForeColor = System.Drawing.Color.Gainsboro;
            this.ibtnRegistrar.IconChar = FontAwesome.Sharp.IconChar.AddressBook;
            this.ibtnRegistrar.IconColor = System.Drawing.Color.Gainsboro;
            this.ibtnRegistrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnRegistrar.IconSize = 32;
            this.ibtnRegistrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnRegistrar.Location = new System.Drawing.Point(0, 140);
            this.ibtnRegistrar.Name = "ibtnRegistrar";
            this.ibtnRegistrar.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.ibtnRegistrar.Size = new System.Drawing.Size(220, 60);
            this.ibtnRegistrar.TabIndex = 1;
            this.ibtnRegistrar.Text = "Registrar Usuario";
            this.ibtnRegistrar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnRegistrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ibtnRegistrar.UseVisualStyleBackColor = true;
            this.ibtnRegistrar.Click += new System.EventHandler(this.ibtnRegistrar_Click_1);
            // 
            // PanelLogo
            // 
            this.PanelLogo.Controls.Add(this.pSalvar);
            this.PanelLogo.Controls.Add(this.btnHome);
            this.PanelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelLogo.Location = new System.Drawing.Point(0, 0);
            this.PanelLogo.Name = "PanelLogo";
            this.PanelLogo.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.PanelLogo.Size = new System.Drawing.Size(220, 140);
            this.PanelLogo.TabIndex = 0;
            // 
            // PanelBarraTitulo
            // 
            this.PanelBarraTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.PanelBarraTitulo.Controls.Add(this.ibtnMinimizar);
            this.PanelBarraTitulo.Controls.Add(this.ibtnMaximizar);
            this.PanelBarraTitulo.Controls.Add(this.ibtnCerrar);
            this.PanelBarraTitulo.Controls.Add(this.lblHome);
            this.PanelBarraTitulo.Controls.Add(this.iconHome);
            this.PanelBarraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelBarraTitulo.Location = new System.Drawing.Point(220, 0);
            this.PanelBarraTitulo.Name = "PanelBarraTitulo";
            this.PanelBarraTitulo.Size = new System.Drawing.Size(1014, 75);
            this.PanelBarraTitulo.TabIndex = 5;
            this.PanelBarraTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PanelBarraTitulo_MouseDown_1);
            // 
            // PanelMenu
            // 
            this.PanelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.PanelMenu.Controls.Add(this.ibtnEliminar);
            this.PanelMenu.Controls.Add(this.txtId);
            this.PanelMenu.Controls.Add(this.ibtnCalificaciones);
            this.PanelMenu.Controls.Add(this.ibtnRegistrar);
            this.PanelMenu.Controls.Add(this.PanelLogo);
            this.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelMenu.Location = new System.Drawing.Point(0, 0);
            this.PanelMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PanelMenu.Name = "PanelMenu";
            this.PanelMenu.Size = new System.Drawing.Size(220, 597);
            this.PanelMenu.TabIndex = 4;
            // 
            // ibtnEliminar
            // 
            this.ibtnEliminar.Dock = System.Windows.Forms.DockStyle.Top;
            this.ibtnEliminar.FlatAppearance.BorderSize = 0;
            this.ibtnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ibtnEliminar.ForeColor = System.Drawing.Color.Gainsboro;
            this.ibtnEliminar.IconChar = FontAwesome.Sharp.IconChar.TrashAlt;
            this.ibtnEliminar.IconColor = System.Drawing.Color.Gainsboro;
            this.ibtnEliminar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnEliminar.IconSize = 32;
            this.ibtnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnEliminar.Location = new System.Drawing.Point(0, 260);
            this.ibtnEliminar.Name = "ibtnEliminar";
            this.ibtnEliminar.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.ibtnEliminar.Size = new System.Drawing.Size(220, 60);
            this.ibtnEliminar.TabIndex = 5;
            this.ibtnEliminar.Text = "Eliminar Cuenta";
            this.ibtnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ibtnEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ibtnEliminar.UseVisualStyleBackColor = true;
            this.ibtnEliminar.Click += new System.EventHandler(this.ibtnEliminar_Click);
            // 
            // FrmPAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 597);
            this.Controls.Add(this.PanelEscritorio);
            this.Controls.Add(this.PanelSombra);
            this.Controls.Add(this.PanelBarraTitulo);
            this.Controls.Add(this.PanelMenu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmPAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPAdmin";
            this.Load += new System.EventHandler(this.FrmPAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelEscritorio.ResumeLayout(false);
            this.PanelEscritorio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconHome)).EndInit();
            this.PanelLogo.ResumeLayout(false);
            this.PanelBarraTitulo.ResumeLayout(false);
            this.PanelBarraTitulo.PerformLayout();
            this.PanelMenu.ResumeLayout(false);
            this.PanelMenu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pSalvar;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Panel PanelEscritorio;
        private System.Windows.Forms.Panel PanelSombra;
        private System.Windows.Forms.Timer tHora;
        private FontAwesome.Sharp.IconPictureBox ibtnMinimizar;
        private FontAwesome.Sharp.IconPictureBox ibtnMaximizar;
        private System.Windows.Forms.PictureBox btnHome;
        private FontAwesome.Sharp.IconPictureBox ibtnCerrar;
        private System.Windows.Forms.Label lblHome;
        private FontAwesome.Sharp.IconPictureBox iconHome;
        private System.Windows.Forms.TextBox txtId;
        private FontAwesome.Sharp.IconButton ibtnCalificaciones;
        private FontAwesome.Sharp.IconButton ibtnRegistrar;
        private System.Windows.Forms.Panel PanelLogo;
        private System.Windows.Forms.Panel PanelBarraTitulo;
        private System.Windows.Forms.Panel PanelMenu;
        private FontAwesome.Sharp.IconButton ibtnEliminar;
    }
}