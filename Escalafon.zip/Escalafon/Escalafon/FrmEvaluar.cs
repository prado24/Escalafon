﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using FontAwesome.Sharp;

namespace Escalafon
{
    public partial class FrmEvaluar : Form
    {
        public FrmEvaluar()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private SqlConnection Conexion;
        private void FrmEvaluar_Load(object sender, EventArgs e)
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            
            string Consultar = ("EXEC MostrarCali");
            Conexion.Open();
            SqlDataAdapter adaptador = new SqlDataAdapter(Consultar, Conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dgvUsuarios.DataSource = dt;
            DataView dtv = dt.DefaultView;
            dtv.Sort = "Calificacion DESC";
            dt = dtv.ToTable();
        }
        public struct Datos
        {
            public int id;
        }
        private void btnCalificar_Click(object sender, EventArgs e)
        {
            if (dgvUsuarios.Rows.Count > 0)
            {
                Datos info;
                info.id = int.Parse(dgvUsuarios.Rows[dgvUsuarios.CurrentRow.Index].Cells[0].Value.ToString());
                //FrmInfoUsuarioAdd fiadd = new FrmInfoUsuarioAdd(info);
                FrmInfoCali fc = new FrmInfoCali(info);
                fc.Show();
                //this.Hide();
            }
        }

        private void btnInspeccionar_Click(object sender, EventArgs e)
        {
            if (dgvUsuarios.Rows.Count > 0)
            {
                Datos info2;
                info2.id = int.Parse(dgvUsuarios.Rows[dgvUsuarios.CurrentRow.Index].Cells[0].Value.ToString());
                //FrmInfoUsuarioAdd fiadd = new FrmInfoUsuarioAdd(info);
                FrmCaliAdmin fda = new FrmCaliAdmin(info2);
                fda.Show();
                //fm.Show();
                //this.Hide();
            }
        }
    }
}
