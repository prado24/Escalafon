﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Escalafon
{
    public class FrmAutenticacion
    {
        private SqlConnection Conexion;
        public int Autorizar(string usuario, string contraseña)
        {
                int resultado = -1;
                Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
                var Consultar = new SqlCommand(string.Format("Select * From RUsuarios Where Usuario = '{0}' and Contraseña = '{1}' and Rol = 'admin'", usuario, contraseña ), Conexion);
                Conexion.Open();
                SqlDataReader reader = Consultar.ExecuteReader();
                while(reader.Read())
                {
                    resultado = 50;
                }
                Conexion.Close();
                return resultado;
        }
        public int Autorizar2(string usuario, string contraseña)
        {
            int resultado2 = -1;
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            var Consultar2 = new SqlCommand(string.Format("Select * From RUsuarios Where Usuario = '{0}' and Contraseña = '{1}' and Rol = 'user'", usuario, contraseña), Conexion);
            Conexion.Open();
            SqlDataReader reader2 = Consultar2.ExecuteReader();
            while (reader2.Read())
            {
                resultado2 = 50;
            }
            Conexion.Close();
            return resultado2;
        }
        public int ObtenerId(string usuario, string contraseña)
        {
            int resultado3 = -1;
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            var Consultar3 = new SqlCommand(string.Format("Select Idusu From RUsuarios Where Usuario = '{0}' and Contraseña = '{1}' and Rol = 'user'", usuario, contraseña), Conexion);
            Conexion.Open();
            SqlDataReader reader2 = Consultar3.ExecuteReader();
            while (reader2.Read())
            {
                resultado3 = 50;
            }
            Conexion.Close();
            return resultado3;
        }
        public int Autorizar4(string usuario, string contraseña)
        {
            int resultado = -1;
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            var Consultar = new SqlCommand(string.Format("Select * From RUsuarios Where Usuario = '{0}' and Contraseña = '{1}' and Rol = 'admin'", usuario, contraseña), Conexion);
            Conexion.Open();
            SqlDataReader reader = Consultar.ExecuteReader();
            while (reader.Read())
            {
                resultado = 50;
            }
            Conexion.Close();
            return resultado;
        }
    }
}
