﻿namespace Escalafon
{
    partial class FrmInfoCali
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvInfoU = new System.Windows.Forms.DataGridView();
            this.txtId = new System.Windows.Forms.TextBox();
            this.dgvFecha = new System.Windows.Forms.DataGridView();
            this.lblCalificacion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbGrado = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbAntiguedad = new System.Windows.Forms.CheckBox();
            this.cmbCursos = new System.Windows.Forms.ComboBox();
            this.lblCursos = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cbDPI = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cbDTesis = new System.Windows.Forms.CheckBox();
            this.cmbICursos = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ibtnCerrar = new FontAwesome.Sharp.IconPictureBox();
            this.npdAResidencias = new System.Windows.Forms.NumericUpDown();
            this.npdATitulaciones = new System.Windows.Forms.NumericUpDown();
            this.npdCertificaciones = new System.Windows.Forms.NumericUpDown();
            this.npdDiplomado = new System.Windows.Forms.NumericUpDown();
            this.npdCrussoST = new System.Windows.Forms.NumericUpDown();
            this.npdICursos = new System.Windows.Forms.NumericUpDown();
            this.npdICertificados = new System.Windows.Forms.NumericUpDown();
            this.npdIDiplomados = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.txtComentario = new System.Windows.Forms.TextBox();
            this.lblComentario = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAntiguedad = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnReinicar = new Escalafon.EstiloBoton();
            this.btnAgregar = new Escalafon.EstiloBoton();
            this.txtVer = new Escalafon.EstiloBoton();
            this.btnGuardar = new Escalafon.EstiloBoton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInfoU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFecha)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdAResidencias)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdATitulaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdCertificaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdDiplomado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdCrussoST)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdICursos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdICertificados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdIDiplomados)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvInfoU
            // 
            this.dgvInfoU.AllowUserToAddRows = false;
            this.dgvInfoU.AllowUserToOrderColumns = true;
            this.dgvInfoU.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvInfoU.BackgroundColor = System.Drawing.Color.White;
            this.dgvInfoU.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvInfoU.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInfoU.GridColor = System.Drawing.Color.White;
            this.dgvInfoU.Location = new System.Drawing.Point(466, 465);
            this.dgvInfoU.Name = "dgvInfoU";
            this.dgvInfoU.ReadOnly = true;
            this.dgvInfoU.RowHeadersVisible = false;
            this.dgvInfoU.Size = new System.Drawing.Size(467, 165);
            this.dgvInfoU.TabIndex = 0;
            // 
            // txtId
            // 
            this.txtId.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtId.Location = new System.Drawing.Point(1079, 326);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(75, 26);
            this.txtId.TabIndex = 2;
            this.txtId.Visible = false;
            // 
            // dgvFecha
            // 
            this.dgvFecha.AllowUserToOrderColumns = true;
            this.dgvFecha.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFecha.BackgroundColor = System.Drawing.Color.White;
            this.dgvFecha.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvFecha.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFecha.Location = new System.Drawing.Point(145, 539);
            this.dgvFecha.Name = "dgvFecha";
            this.dgvFecha.ReadOnly = true;
            this.dgvFecha.RowHeadersVisible = false;
            this.dgvFecha.Size = new System.Drawing.Size(233, 39);
            this.dgvFecha.TabIndex = 4;
            this.dgvFecha.Visible = false;
            // 
            // lblCalificacion
            // 
            this.lblCalificacion.AutoSize = true;
            this.lblCalificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalificacion.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblCalificacion.Location = new System.Drawing.Point(1108, 293);
            this.lblCalificacion.Name = "lblCalificacion";
            this.lblCalificacion.Size = new System.Drawing.Size(17, 18);
            this.lblCalificacion.TabIndex = 5;
            this.lblCalificacion.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(1067, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Calificación:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(428, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "Grado:";
            // 
            // cmbGrado
            // 
            this.cmbGrado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGrado.FormattingEnabled = true;
            this.cmbGrado.Items.AddRange(new object[] {
            "Doctorado",
            "Maestria",
            "Licenciatura"});
            this.cmbGrado.Location = new System.Drawing.Point(494, 163);
            this.cmbGrado.Name = "cmbGrado";
            this.cmbGrado.Size = new System.Drawing.Size(133, 28);
            this.cmbGrado.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(142, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "Antiguedad:";
            // 
            // cbAntiguedad
            // 
            this.cbAntiguedad.AutoSize = true;
            this.cbAntiguedad.Location = new System.Drawing.Point(247, 122);
            this.cbAntiguedad.Name = "cbAntiguedad";
            this.cbAntiguedad.Size = new System.Drawing.Size(15, 14);
            this.cbAntiguedad.TabIndex = 10;
            this.cbAntiguedad.UseVisualStyleBackColor = true;
            // 
            // cmbCursos
            // 
            this.cmbCursos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCursos.FormattingEnabled = true;
            this.cmbCursos.Items.AddRange(new object[] {
            "Mayor a 30hrs",
            "Menor a 30hrs"});
            this.cmbCursos.Location = new System.Drawing.Point(494, 119);
            this.cmbCursos.Name = "cmbCursos";
            this.cmbCursos.Size = new System.Drawing.Size(133, 28);
            this.cmbCursos.TabIndex = 12;
            // 
            // lblCursos
            // 
            this.lblCursos.AutoSize = true;
            this.lblCursos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCursos.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblCursos.Location = new System.Drawing.Point(420, 122);
            this.lblCursos.Name = "lblCursos";
            this.lblCursos.Size = new System.Drawing.Size(68, 18);
            this.lblCursos.TabIndex = 11;
            this.lblCursos.Text = "Cursos:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(784, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 18);
            this.label4.TabIndex = 13;
            this.label4.Text = "Certificaciones:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(812, 344);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 18);
            this.label5.TabIndex = 15;
            this.label5.Text = "Diplomados:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(746, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 18);
            this.label6.TabIndex = 17;
            this.label6.Text = "Impartición de CST:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(309, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(179, 18);
            this.label7.TabIndex = 19;
            this.label7.Text = "Impartición de Cursos:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(780, 216);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(131, 18);
            this.label8.TabIndex = 21;
            this.label8.Text = "Instructor Certs:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gainsboro;
            this.label9.Location = new System.Drawing.Point(31, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(206, 18);
            this.label9.TabIndex = 23;
            this.label9.Text = "Desarrollo de Proyectos I:";
            // 
            // cbDPI
            // 
            this.cbDPI.AutoSize = true;
            this.cbDPI.Location = new System.Drawing.Point(247, 85);
            this.cbDPI.Name = "cbDPI";
            this.cbDPI.Size = new System.Drawing.Size(15, 14);
            this.cbDPI.TabIndex = 24;
            this.cbDPI.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(745, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(163, 18);
            this.label10.TabIndex = 25;
            this.label10.Text = "Asesor Residencias:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(747, 169);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(162, 18);
            this.label11.TabIndex = 27;
            this.label11.Text = "Asesor Titulaciones:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gainsboro;
            this.label12.Location = new System.Drawing.Point(78, 150);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 18);
            this.label12.TabIndex = 29;
            this.label12.Text = "Dirección de Tesis:";
            // 
            // cbDTesis
            // 
            this.cbDTesis.AutoSize = true;
            this.cbDTesis.Location = new System.Drawing.Point(247, 154);
            this.cbDTesis.Name = "cbDTesis";
            this.cbDTesis.Size = new System.Drawing.Size(15, 14);
            this.cbDTesis.TabIndex = 30;
            this.cbDTesis.UseVisualStyleBackColor = true;
            // 
            // cmbICursos
            // 
            this.cmbICursos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbICursos.FormattingEnabled = true;
            this.cmbICursos.Items.AddRange(new object[] {
            "Mayor a 30hrs",
            "Menor a 30hrs"});
            this.cmbICursos.Location = new System.Drawing.Point(494, 78);
            this.cmbICursos.Name = "cmbICursos";
            this.cmbICursos.Size = new System.Drawing.Size(133, 28);
            this.cmbICursos.TabIndex = 31;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Gainsboro;
            this.label13.Location = new System.Drawing.Point(429, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(363, 29);
            this.label13.TabIndex = 0;
            this.label13.Text = "Evaluar Información de Usario";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.panel1.Controls.Add(this.ibtnCerrar);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1241, 56);
            this.panel1.TabIndex = 33;
            // 
            // ibtnCerrar
            // 
            this.ibtnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.ibtnCerrar.ForeColor = System.Drawing.Color.MediumPurple;
            this.ibtnCerrar.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.ibtnCerrar.IconColor = System.Drawing.Color.MediumPurple;
            this.ibtnCerrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnCerrar.IconSize = 31;
            this.ibtnCerrar.Location = new System.Drawing.Point(1209, 0);
            this.ibtnCerrar.Name = "ibtnCerrar";
            this.ibtnCerrar.Size = new System.Drawing.Size(32, 31);
            this.ibtnCerrar.TabIndex = 181;
            this.ibtnCerrar.TabStop = false;
            this.ibtnCerrar.Click += new System.EventHandler(this.ibtnCerrar_Click);
            // 
            // npdAResidencias
            // 
            this.npdAResidencias.Location = new System.Drawing.Point(927, 126);
            this.npdAResidencias.Name = "npdAResidencias";
            this.npdAResidencias.Size = new System.Drawing.Size(46, 26);
            this.npdAResidencias.TabIndex = 36;
            this.npdAResidencias.ThousandsSeparator = true;
            // 
            // npdATitulaciones
            // 
            this.npdATitulaciones.Location = new System.Drawing.Point(926, 167);
            this.npdATitulaciones.Name = "npdATitulaciones";
            this.npdATitulaciones.Size = new System.Drawing.Size(46, 26);
            this.npdATitulaciones.TabIndex = 37;
            this.npdATitulaciones.ThousandsSeparator = true;
            // 
            // npdCertificaciones
            // 
            this.npdCertificaciones.Location = new System.Drawing.Point(926, 295);
            this.npdCertificaciones.Name = "npdCertificaciones";
            this.npdCertificaciones.Size = new System.Drawing.Size(46, 26);
            this.npdCertificaciones.TabIndex = 38;
            this.npdCertificaciones.ThousandsSeparator = true;
            // 
            // npdDiplomado
            // 
            this.npdDiplomado.Location = new System.Drawing.Point(926, 341);
            this.npdDiplomado.Name = "npdDiplomado";
            this.npdDiplomado.Size = new System.Drawing.Size(46, 26);
            this.npdDiplomado.TabIndex = 39;
            this.npdDiplomado.ThousandsSeparator = true;
            // 
            // npdCrussoST
            // 
            this.npdCrussoST.Location = new System.Drawing.Point(926, 78);
            this.npdCrussoST.Name = "npdCrussoST";
            this.npdCrussoST.Size = new System.Drawing.Size(46, 26);
            this.npdCrussoST.TabIndex = 40;
            this.npdCrussoST.ThousandsSeparator = true;
            // 
            // npdICursos
            // 
            this.npdICursos.Location = new System.Drawing.Point(650, 79);
            this.npdICursos.Name = "npdICursos";
            this.npdICursos.Size = new System.Drawing.Size(46, 26);
            this.npdICursos.TabIndex = 41;
            this.npdICursos.ThousandsSeparator = true;
            // 
            // npdICertificados
            // 
            this.npdICertificados.Location = new System.Drawing.Point(927, 212);
            this.npdICertificados.Name = "npdICertificados";
            this.npdICertificados.Size = new System.Drawing.Size(46, 26);
            this.npdICertificados.TabIndex = 42;
            this.npdICertificados.ThousandsSeparator = true;
            // 
            // npdIDiplomados
            // 
            this.npdIDiplomados.Location = new System.Drawing.Point(926, 255);
            this.npdIDiplomados.Name = "npdIDiplomados";
            this.npdIDiplomados.Size = new System.Drawing.Size(46, 26);
            this.npdIDiplomados.TabIndex = 45;
            this.npdIDiplomados.ThousandsSeparator = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gainsboro;
            this.label14.Location = new System.Drawing.Point(791, 258);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(119, 18);
            this.label14.TabIndex = 44;
            this.label14.Text = "Instructor Dipl:";
            // 
            // txtComentario
            // 
            this.txtComentario.Location = new System.Drawing.Point(130, 243);
            this.txtComentario.Multiline = true;
            this.txtComentario.Name = "txtComentario";
            this.txtComentario.Size = new System.Drawing.Size(497, 119);
            this.txtComentario.TabIndex = 46;
            // 
            // lblComentario
            // 
            this.lblComentario.AutoSize = true;
            this.lblComentario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComentario.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblComentario.Location = new System.Drawing.Point(126, 212);
            this.lblComentario.Name = "lblComentario";
            this.lblComentario.Size = new System.Drawing.Size(106, 20);
            this.lblComentario.TabIndex = 47;
            this.lblComentario.Text = "Comentario:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(25)))), ((int)(((byte)(62)))));
            this.panel2.Location = new System.Drawing.Point(0, 379);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1241, 10);
            this.panel2.TabIndex = 48;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gainsboro;
            this.label15.Location = new System.Drawing.Point(531, 401);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(261, 25);
            this.label15.TabIndex = 49;
            this.label15.Text = "Informacion del Usuario";
            // 
            // txtAntiguedad
            // 
            this.txtAntiguedad.Enabled = false;
            this.txtAntiguedad.Location = new System.Drawing.Point(145, 465);
            this.txtAntiguedad.Name = "txtAntiguedad";
            this.txtAntiguedad.ReadOnly = true;
            this.txtAntiguedad.Size = new System.Drawing.Size(227, 26);
            this.txtAntiguedad.TabIndex = 50;
            this.txtAntiguedad.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gainsboro;
            this.label16.Location = new System.Drawing.Point(31, 469);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 18);
            this.label16.TabIndex = 51;
            this.label16.Text = "Antiguedad:";
            // 
            // btnReinicar
            // 
            this.btnReinicar.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnReinicar.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnReinicar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnReinicar.BorderRadius = 25;
            this.btnReinicar.BorderSize = 0;
            this.btnReinicar.FlatAppearance.BorderSize = 0;
            this.btnReinicar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReinicar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnReinicar.Location = new System.Drawing.Point(1036, 151);
            this.btnReinicar.Name = "btnReinicar";
            this.btnReinicar.Size = new System.Drawing.Size(150, 40);
            this.btnReinicar.TabIndex = 43;
            this.btnReinicar.Text = "Reiniciar ";
            this.btnReinicar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnReinicar.UseVisualStyleBackColor = false;
            this.btnReinicar.Click += new System.EventHandler(this.btnReinicar_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnAgregar.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnAgregar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnAgregar.BorderRadius = 25;
            this.btnAgregar.BorderSize = 0;
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnAgregar.Location = new System.Drawing.Point(1035, 85);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(151, 40);
            this.btnAgregar.TabIndex = 32;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // txtVer
            // 
            this.txtVer.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.txtVer.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.txtVer.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.txtVer.BorderRadius = 25;
            this.txtVer.BorderSize = 0;
            this.txtVer.FlatAppearance.BorderSize = 0;
            this.txtVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtVer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.txtVer.Location = new System.Drawing.Point(1033, 493);
            this.txtVer.Name = "txtVer";
            this.txtVer.Size = new System.Drawing.Size(150, 40);
            this.txtVer.TabIndex = 3;
            this.txtVer.Text = "Visualizar";
            this.txtVer.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.txtVer.UseVisualStyleBackColor = false;
            this.txtVer.Click += new System.EventHandler(this.txtVer_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnGuardar.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnGuardar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnGuardar.BorderRadius = 25;
            this.btnGuardar.BorderSize = 0;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnGuardar.Location = new System.Drawing.Point(1033, 562);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(150, 40);
            this.btnGuardar.TabIndex = 1;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // FrmInfoCali
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(1241, 665);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtAntiguedad);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblComentario);
            this.Controls.Add(this.txtComentario);
            this.Controls.Add(this.npdIDiplomados);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.btnReinicar);
            this.Controls.Add(this.npdICertificados);
            this.Controls.Add(this.npdICursos);
            this.Controls.Add(this.npdCrussoST);
            this.Controls.Add(this.npdDiplomado);
            this.Controls.Add(this.npdCertificaciones);
            this.Controls.Add(this.npdATitulaciones);
            this.Controls.Add(this.npdAResidencias);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.cmbICursos);
            this.Controls.Add(this.cbDTesis);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cbDPI);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbCursos);
            this.Controls.Add(this.lblCursos);
            this.Controls.Add(this.cbAntiguedad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbGrado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCalificacion);
            this.Controls.Add(this.dgvFecha);
            this.Controls.Add(this.txtVer);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.dgvInfoU);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmInfoCali";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmInfoCali";
            this.Load += new System.EventHandler(this.FrmInfoCali_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInfoU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFecha)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ibtnCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdAResidencias)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdATitulaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdCertificaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdDiplomado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdCrussoST)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdICursos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdICertificados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npdIDiplomados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvInfoU;
        private EstiloBoton btnGuardar;
        private System.Windows.Forms.TextBox txtId;
        private EstiloBoton txtVer;
        private System.Windows.Forms.DataGridView dgvFecha;
        private System.Windows.Forms.Label lblCalificacion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbGrado;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbAntiguedad;
        private System.Windows.Forms.ComboBox cmbCursos;
        private System.Windows.Forms.Label lblCursos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox cbDPI;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox cbDTesis;
        private System.Windows.Forms.ComboBox cmbICursos;
        private EstiloBoton btnAgregar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown npdAResidencias;
        private System.Windows.Forms.NumericUpDown npdATitulaciones;
        private System.Windows.Forms.NumericUpDown npdCertificaciones;
        private System.Windows.Forms.NumericUpDown npdDiplomado;
        private System.Windows.Forms.NumericUpDown npdCrussoST;
        private System.Windows.Forms.NumericUpDown npdICursos;
        private System.Windows.Forms.NumericUpDown npdICertificados;
        private EstiloBoton btnReinicar;
        private System.Windows.Forms.NumericUpDown npdIDiplomados;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtComentario;
        private System.Windows.Forms.Label lblComentario;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAntiguedad;
        private System.Windows.Forms.Label label16;
        private FontAwesome.Sharp.IconPictureBox ibtnCerrar;
    }
}