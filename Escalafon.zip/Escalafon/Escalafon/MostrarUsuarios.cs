﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Escalafon
{
    public class MostrarUsuarios
    {
        private SqlConnection Conexion;
        public int EvaluarUsuario()
        {
            int resultado = -1;
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
            var Consultar = new SqlCommand(string.Format("Select * From RUsuarios Where Usuario"), Conexion);
            Conexion.Open();
            SqlDataReader reader = Consultar.ExecuteReader();
            //Consultar.ExecuteNonQuery();
            while (reader.Read())
            {
                resultado = 50;
            }
            Conexion.Close();
            return resultado;
        }
    }
}
