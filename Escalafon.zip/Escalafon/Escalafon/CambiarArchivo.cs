﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Escalafon
{
    public class CambiarArchivo
    {
        private SqlConnection Conexion;
        private int idCurso; // El ID del curso que se está modificando.
        /*public bool CambiarArchivo(string nombre, string usuario, string contraseña, string rol)
        {
            try
            {
                Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
                var Insertar = new SqlCommand("EXEC Insertar '" + nombre + "','" + usuario + "','" + contraseña + "','" + rol + "'", Conexion);
                Conexion.Open();
                Insertar.ExecuteNonQuery();
                Conexion.Close();
                return true;
            }
            catch (Exception ex)
            {
                Conexion?.Close();
                return false;
            }
        }*/
    }
}
