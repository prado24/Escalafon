﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace Escalafon
{
    public class UsuariosAdd
    {
        private SqlConnection Conexion;
        public bool Registrarusuarios(string nombre, string usuario, string contraseña, string rol)
        {
            try
            {
                Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
                var Insertar = new SqlCommand("EXEC Insertar '" + nombre + "','" + usuario + "','"+ contraseña + "','" + rol + "'", Conexion);
                Conexion.Open();
                Insertar.ExecuteNonQuery();
                Conexion.Close();
                return true;
            }
            catch (Exception ex)
            {
                Conexion?.Close();
                return false;
            }
        }

        public bool RegistrarCalificacion(string nombre, string usuario, string contraseña, string rol)
        {
            try
            {
                Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");
                var Insertar = new SqlCommand("EXEC Insertar '" + nombre + "','" + usuario + "','" + contraseña + "','" + rol + "'", Conexion);
                Conexion.Open();
                Insertar.ExecuteNonQuery();
                Conexion.Close();
                return true;
            }
            catch (Exception ex)
            {
                Conexion?.Close();
                return false;
            }
        }
    }
}
