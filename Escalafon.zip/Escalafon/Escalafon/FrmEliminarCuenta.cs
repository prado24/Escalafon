﻿using Escalafon.Model2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Escalafon
{
    public partial class FrmEliminarCuenta : Form
    {
        public FrmEliminarCuenta()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if(cmbUsuario.Text != "")
            {
                id = cmbUsuario.SelectedValue.ToString();
                usuario = cmbUsuario.DisplayMember.ToString();
                DialogResult result = MessageBox.Show("Esta seguro de eliminar este usuario?", usuario, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.OK)
                {
                    MessageBox.Show("Usuario Eliminado con exito", id, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    EliminarUser();
                }
                else if (result == DialogResult.Cancel)
                {

                }
            }
            else
            {
                MessageBox.Show("Primero selecciona un usuario para eliminar","", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        string id;
        string usuario;
        private SqlConnection Conexion;
        public void MostrarUser()
        {
            Conexion = new SqlConnection("Data Source=AFANTASMA\\MARIA; Initial Catalog=Escalafon; User ID=sa; Password=Scaam7GG");

            var Consultar4 = new SqlCommand(string.Format("Select Idusu, Usuario From RUsuarios Where Rol = 'user'"), Conexion);
            Conexion.Open();
            //SqlDataReader reader2 = Consultar4.ExecuteReader();
            SqlDataReader reader2 = Consultar4.ExecuteReader();
            //if (reader2.Read())
            //{
            //    id = int.Parse(cmbUsuario.SelectedValue.ToString());
            //}
            DataTable dataTable = new DataTable();
            dataTable.Load(reader2);
            cmbUsuario.DataSource = dataTable;
            cmbUsuario.DisplayMember = "Usuario";
            cmbUsuario.ValueMember = "Idusu";
            reader2.Close();
            Conexion.Close();
            
        }
        public void EliminarUser()
        {
            string connectionString = "Server=AFANTASMA\\MARIA;Database=Escalafon;User Id=sa;Password=Scaam7GG;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();// Crear un comando para ejecutar el procedimiento almacenado.
                using (SqlCommand command = new SqlCommand("EliminarUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Pasar los parámetros al procedimiento almacenado.
                    command.Parameters.AddWithValue("@fkidusu", int.Parse(id));

                    // Ejecutar el procedimiento almacenado.
                    command.ExecuteNonQuery();

                    //MessageBox.Show("Documento modificado correctamente.");
                    MessageBox.Show("Documento eliminado correctamente", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            MostrarUser();
        }
        private void FrmEliminarCuenta_Load(object sender, EventArgs e)
        {
            MostrarUser();
        }
    }
}
