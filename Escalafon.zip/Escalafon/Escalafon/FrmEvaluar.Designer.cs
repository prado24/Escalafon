﻿namespace Escalafon
{
    partial class FrmEvaluar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalificar = new Escalafon.EstiloBoton();
            this.dgvUsuarios = new System.Windows.Forms.DataGridView();
            this.btnInspeccionar = new Escalafon.EstiloBoton();
            this.btnActulizar = new Escalafon.EstiloBoton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsuarios)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCalificar
            // 
            this.btnCalificar.BackColor = System.Drawing.Color.MediumPurple;
            this.btnCalificar.BackgroundColor = System.Drawing.Color.MediumPurple;
            this.btnCalificar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnCalificar.BorderRadius = 25;
            this.btnCalificar.BorderSize = 0;
            this.btnCalificar.FlatAppearance.BorderSize = 0;
            this.btnCalificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalificar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnCalificar.Location = new System.Drawing.Point(574, 62);
            this.btnCalificar.Name = "btnCalificar";
            this.btnCalificar.Size = new System.Drawing.Size(150, 40);
            this.btnCalificar.TabIndex = 13;
            this.btnCalificar.Text = "Calificar";
            this.btnCalificar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnCalificar.UseVisualStyleBackColor = false;
            this.btnCalificar.Click += new System.EventHandler(this.btnCalificar_Click);
            // 
            // dgvUsuarios
            // 
            this.dgvUsuarios.AllowUserToAddRows = false;
            this.dgvUsuarios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsuarios.EnableHeadersVisualStyles = false;
            this.dgvUsuarios.Location = new System.Drawing.Point(28, 62);
            this.dgvUsuarios.Name = "dgvUsuarios";
            this.dgvUsuarios.ReadOnly = true;
            this.dgvUsuarios.RowHeadersVisible = false;
            this.dgvUsuarios.Size = new System.Drawing.Size(480, 284);
            this.dgvUsuarios.TabIndex = 14;
            // 
            // btnInspeccionar
            // 
            this.btnInspeccionar.BackColor = System.Drawing.Color.MediumPurple;
            this.btnInspeccionar.BackgroundColor = System.Drawing.Color.MediumPurple;
            this.btnInspeccionar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnInspeccionar.BorderRadius = 25;
            this.btnInspeccionar.BorderSize = 0;
            this.btnInspeccionar.FlatAppearance.BorderSize = 0;
            this.btnInspeccionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInspeccionar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnInspeccionar.Location = new System.Drawing.Point(574, 196);
            this.btnInspeccionar.Name = "btnInspeccionar";
            this.btnInspeccionar.Size = new System.Drawing.Size(150, 40);
            this.btnInspeccionar.TabIndex = 15;
            this.btnInspeccionar.Text = "Inspeccionar";
            this.btnInspeccionar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnInspeccionar.UseVisualStyleBackColor = false;
            this.btnInspeccionar.Click += new System.EventHandler(this.btnInspeccionar_Click);
            // 
            // btnActulizar
            // 
            this.btnActulizar.BackColor = System.Drawing.Color.MediumPurple;
            this.btnActulizar.BackgroundColor = System.Drawing.Color.MediumPurple;
            this.btnActulizar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnActulizar.BorderRadius = 25;
            this.btnActulizar.BorderSize = 0;
            this.btnActulizar.FlatAppearance.BorderSize = 0;
            this.btnActulizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActulizar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnActulizar.Location = new System.Drawing.Point(574, 130);
            this.btnActulizar.Name = "btnActulizar";
            this.btnActulizar.Size = new System.Drawing.Size(150, 40);
            this.btnActulizar.TabIndex = 16;
            this.btnActulizar.Text = "Actualizar";
            this.btnActulizar.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(36)))), ((int)(((byte)(81)))));
            this.btnActulizar.UseVisualStyleBackColor = false;
            this.btnActulizar.Click += new System.EventHandler(this.btnActulizar_Click);
            // 
            // FrmEvaluar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(33)))), ((int)(((byte)(74)))));
            this.ClientSize = new System.Drawing.Size(776, 470);
            this.Controls.Add(this.btnActulizar);
            this.Controls.Add(this.btnInspeccionar);
            this.Controls.Add(this.dgvUsuarios);
            this.Controls.Add(this.btnCalificar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmEvaluar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmEvaluar";
            this.Load += new System.EventHandler(this.FrmEvaluar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsuarios)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private EstiloBoton btnCalificar;
        private System.Windows.Forms.DataGridView dgvUsuarios;
        private EstiloBoton btnInspeccionar;
        private EstiloBoton btnActulizar;
    }
}